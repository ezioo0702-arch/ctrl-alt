import { initializeApp } from 'firebase/app';
import { getFirestore, serverTimestamp } from 'firebase/firestore';

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAaq3SYT7_2ecmJviyQzNJNIonvp5NGUq4",
  authDomain: "ctrl-24406.firebaseapp.com",
  projectId: "ctrl-24406",
  storageBucket: "ctrl-24406.firebasestorage.app",
  messagingSenderId: "425293663143",
  appId: "1:425293663143:web:37eb37e0f04887ece74482",
  measurementId: "G-EFZJT5XC2Q"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Cloud Firestore and get a reference to the service
const db = getFirestore(app);

export { db, serverTimestamp };
