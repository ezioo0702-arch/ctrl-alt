import React from 'react';
import Iridescence from './Iridescence';
import { FlipWords } from "../components/FlipWords";
import ShinyText from "./ShinyText";

interface WelcomePageProps {
  onNext: () => void;
}

const Page01_Welcome: React.FC<WelcomePageProps> = ({ onNext }) => {
  return (
    <div className="min-h-screen w-full relative">
      {/* Iridescence Background */}
      <div className="absolute inset-0 z-0">
        <Iridescence
          color={[0.6, 0.6, 0.9]}
          mouseReact={false}
          amplitude={0.1}
          speed={1.0}
        />
      </div>

      {/* Main Content Overlay */}
      <div className="relative z-10 flex flex-col justify-center items-center text-center p-4 min-h-screen">
        
        <h1 className="text-5xl md:text-7xl font-bold text-white tracking-tight">
  <span
    className="flex items-center justify-center"
    style={{
      height: "1.2em",
      padding: "0.3em 0",
      lineHeight: "1.2em",
      display: "flex",
      alignItems: "center",
    }}
  >
    <FlipWords
      words={[
        "CTRL + ALT + SELF",
        "rewire your mind",
        "upgrade your reality",
      ]}
    />
  </span>
</h1>
<ShinyText
        
        text="a 4-week philosophical path integration to clear perspective"
        speed={3}
       className="text-white/70 text-lg mt-4">
//
</ShinyText>
        <button
          onClick={onNext}
          className="mt-10 relative flex items-center justify-center gap-2 px-6 py-3 rounded-full font-semibold text-white
                     bg-gradient-to-r from-purple-600 to-blue-500 shadow-md transition-all duration-300
                     overflow-hidden group"
        >
          <span className="absolute inset-0 bg-gradient-to-r from-blue-600 to-purple-700
                           transform scale-x-0 origin-left transition-transform duration-300 ease-out
                           group-hover:scale-x-100"></span>
          <span className="relative z-10 flex items-center gap-2">
            Start Your Journey
            <span>→</span>
          </span>
        </button>
      </div>
    </div>
  );
};

export default Page01_Welcome;
