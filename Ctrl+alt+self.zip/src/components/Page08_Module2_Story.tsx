import React, { useState } from 'react';
import Iridescence from './Iridescence';
import { BookOpen, Edit, Lightbulb } from 'lucide-react'; // Added Lightbulb icon
import saveFormData from '../utils/saveFormData'; // Import saveFormData

interface PageProps {
  onNext: () => void;
  onPrev: () => void;
}

const Page08_Module2_Story: React.FC<PageProps> = ({ onNext, onPrev }) => {
  const [reflectionText, setReflectionText] = useState('');
  const [submissionStatus, setSubmissionStatus] = useState<'success' | 'error' | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmissionStatus(null);

    const success = await saveFormData('module2Reflections', { reflection: reflectionText });

    if (success) {
      setSubmissionStatus('success');
      setReflectionText(''); // Clear form
      // Delay navigation to allow success message to be seen
      setTimeout(() => {
        onNext();
      }, 1000); // 1 second delay
    } else {
      setSubmissionStatus('error');
      // Do not navigate on error
    }
  };

  return (
    <div className="relative min-h-screen w-full overflow-hidden">
      <Iridescence color={[0.7, 0.85, 0.7]} speed={0.8} amplitude={0.07} mouseReact={true} />
      <div className="relative z-10 min-h-screen w-full flex flex-col justify-center items-center text-center p-4 py-12">
        <form onSubmit={handleSubmit} className="max-w-3xl mx-auto bg-white rounded-3xl shadow-xl p-8 md:p-12 space-y-8 border border-gray-200">
          <h2 className="text-3xl font-bold text-gray-800 tracking-tight mb-4 flex items-center justify-center gap-3">
            <Lightbulb className="text-yellow-500" size={36} />
            MODULE TWO
          </h2>
          <h1 className="text-4xl font-bold text-gray-800 tracking-tight mb-4">
            Change Is the Only Constant
          </h1>

          {/* Philosophy Section */}
          <div className="bg-yellow-50 border-l-4 border-yellow-400 p-6 rounded-r-lg text-left flex flex-col gap-4 shadow-sm">
            <h3 className="text-2xl font-semibold text-yellow-700 flex items-center gap-2">
              <Lightbulb className="text-yellow-500" size={28} />
              Philosophy: Karma Yoga & Growth Mindset
            </h3>
            <p className="text-gray-700 leading-relaxed">
              Karma Yoga (Bhagavad Gita) teaches us to act sincerely without attachment to results.
            </p>
            <p className="text-gray-700 leading-relaxed">
              Carol Dweck's Growth Mindset echoes the same truth – that effort is the true path to mastery.
            </p>
          </div>

          {/* Story Section */}
          <div className="bg-green-50 border-l-4 border-green-400 p-6 rounded-r-lg text-left flex flex-col gap-4 shadow-sm">
            <h3 className="text-2xl font-semibold text-green-700 flex items-center gap-2">
              <BookOpen className="text-green-500" size={28} />
              Story: The Gardener's Lesson
            </h3>
            <p className="text-gray-700 leading-relaxed">
              A gardener named Meera planted jasmine seeds every spring. This year, nothing grew. Weeks passed. Disappointment took root. One day, a small basil sprouted instead – the result of a misplaced seed.
            </p>
            <blockquote className="border-l-2 border-gray-300 pl-4 italic text-gray-700 text-lg py-2">
              Meera smiled and cared for it anyway. When it bloomed, she realized:
              <br />
              "I didn't get what I wanted — but I grew what I needed."
            </blockquote>
          </div>

          {/* Moral Section */}
          <div className="bg-blue-50 border-l-4 border-blue-400 p-6 rounded-r-lg text-left flex flex-col gap-4 shadow-sm">
            <h3 className="text-2xl font-semibold text-blue-700 flex items-center gap-2">
              <Lightbulb className="text-blue-500" size={28} />
              Moral
            </h3>
            <p className="text-gray-700 leading-relaxed">
              Acceptance transforms effort into peace.
            </p>
          </div>

          {/* Reflection Section */}
          <div className="bg-purple-50 border-l-4 border-purple-400 p-6 rounded-r-lg text-left flex flex-col gap-4 shadow-sm">
            <h3 className="text-2xl font-semibold text-purple-700 flex items-center gap-2">
              <Edit className="text-purple-500" size={28} />
              Reflection
            </h3>
            <p className="text-gray-700">
              What part of your life feels uncertain right now?
              <br />
              How can you nurture it with patience instead of control?
            </p>
            <textarea
              className="w-full p-4 rounded-xl bg-gray-50 border border-gray-300 text-gray-700 placeholder-gray-500 focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200 min-h-[150px]"
              placeholder="Reflect on uncertainty and patience..."
              value={reflectionText}
              onChange={(e) => setReflectionText(e.target.value)}
            ></textarea>
            {submissionStatus === 'success' && (
              <p className="text-success text-center">✅ Submitted successfully!</p>
            )}
            {submissionStatus === 'error' && (
              <p className="text-error text-center">❌ Submission failed. Please try again.</p>
            )}
          </div>

          <div className="flex justify-between mt-10">
            <button
              type="button"
              onClick={onPrev}
              className="px-6 py-2 rounded-full font-semibold text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 shadow-sm transition-colors flex items-center gap-1"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
              Previous
            </button>
            <button
              type="submit"
              className="flex items-center justify-center gap-2 px-6 py-2 rounded-full font-semibold text-white bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 shadow-md transition-all"
            >
              Next <span>→</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Page08_Module2_Story;
