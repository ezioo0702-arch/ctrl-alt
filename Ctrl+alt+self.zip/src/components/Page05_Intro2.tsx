import React from 'react';
import Iridescence from './Iridescence';
import { Quote, Sparkles } from 'lucide-react';

interface PageProps {
  onNext: () => void;
  onPrev: () => void;
}

const Page05_Intro2: React.FC<PageProps> = ({ onNext, onPrev }) => {
  return (
    <div className="relative min-h-screen w-full overflow-hidden">
      <Iridescence color={[0.8, 0.5, 0.7]} speed={1.0} amplitude={0.08} mouseReact={true} />
      <div className="relative z-10 min-h-screen w-full flex flex-col justify-center items-center text-center p-4 py-12">
        <div className="max-w-3xl mx-auto bg-white rounded-3xl shadow-2xl p-8 md:p-12 space-y-8 border border-border">
          <h2 className="text-4xl font-bold text-gray-900 tracking-tight mb-4 flex items-center justify-center gap-3">
            <Sparkles className="text-accent" size={36} />
            The Path to Integration
          </h2>
          <p className="text-lg text-gray-900 leading-relaxed">
            This course is a "path integration" – a journey to bring together the disparate parts of your experience. It's about recognizing the threads that connect your past, present, and future; your mind, body, and spirit; your individual self and the collective.
          </p>
          <p className="text-lg text-gray-900 leading-relaxed">
            Through stories, reflections, and practices, you will learn to weave these threads into a coherent tapestry, revealing a more complete and authentic version of yourself.
          </p>

          <blockquote className="bg-purple-50 border-l-4 border-purple-400 p-6 rounded-r-lg italic text-gray-900 text-lg my-8 text-left">
            <Quote className="text-purple-400 inline-block mr-2" size={24} />
            "The greatest discovery of all time is that a person can change his future by merely changing his attitude."
            <footer className="mt-2 text-sm text-gray-700">— Oprah Winfrey</footer>
          </blockquote>

          <p className="text-center text-gray-900 font-medium mt-8">
            Are you ready to embark on this transformative journey?
          </p>

          <div className="flex justify-between mt-10">
            <button
              onClick={onPrev}
              className="px-6 py-2 rounded-full font-semibold text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 shadow-sm transition-colors"
            >
              Previous
            </button>
            <button
              onClick={onNext}
              className="flex items-center justify-center gap-2 px-6 py-2 rounded-full font-semibold text-white bg-gradient-to-r from-purple-600 to-blue-500 hover:from-purple-700 hover:to-blue-600 shadow-md transition-all"
            >
              Next <span>→</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Page05_Intro2;
