import React, { useState } from 'react';
import Iridescence from './Iridescence';
import { CheckSquare, Star } from 'lucide-react';
import saveFormData from '../utils/saveFormData';

interface PageProps {
  onNext: () => void;
  onPrev: () => void;
}

const Page13_Module4_Practice: React.FC<PageProps> = ({ onNext, onPrev }) => {
  const [starRating, setStarRating] = useState(0);
  const [checklist, setChecklist] = useState({
    practicedEmpathy: false,
    strengthenedConnection: false,
    recognizedInterdependence: false,
  });
  const [submissionStatus, setSubmissionStatus] = useState<'success' | 'error' | null>(null);

  const handleStarClick = (rating: number) => {
    setStarRating(rating);
  };

  const handleChecklistChange = (item: keyof typeof checklist) => {
    setChecklist((prev) => ({ ...prev, [item]: !prev[item] }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmissionStatus(null);

    const dataToSave = {
      starRating,
      checklist,
    };

    const success = await saveFormData('module4Practice', dataToSave);

    if (success) {
      setSubmissionStatus('success');
      setStarRating(0);
      setChecklist({
        practicedEmpathy: false,
        strengthenedConnection: false,
        recognizedInterdependence: false,
      });
      setTimeout(() => {
        onNext();
      }, 1000);
    } else {
      setSubmissionStatus('error');
    }
  };

  return (
    <div className="relative min-h-screen w-full overflow-hidden">
      <Iridescence color={[0.7, 0.8, 0.6]} speed={0.8} amplitude={0.07} mouseReact={true} />
      <div className="relative z-10 min-h-screen w-full flex flex-col justify-center items-center text-center p-4 py-12">
        <form onSubmit={handleSubmit} className="max-w-3xl mx-auto bg-white rounded-3xl shadow-2xl p-8 md:p-12 space-y-8 border border-border">
          <h2 className="text-4xl font-bold text-gray-900 tracking-tight mb-4 flex items-center justify-center gap-3">
            <CheckSquare className="text-success" size={36} />
            Module 4: Practice - Weaving Connections
          </h2>
          <p className="text-lg text-gray-900 leading-relaxed">
            Anya's wisdom reminds us of our interconnectedness. Let's strengthen the threads that bind us.
          </p>

          <div className="space-y-4 text-left">
            <h3 className="text-2xl font-semibold text-gray-900 flex items-center gap-2">
              <CheckSquare className="text-success" size={28} />
              Self-Assessment Checklist
            </h3>
            <div className="space-y-2">
              <label className="flex items-center gap-3 text-gray-900 cursor-pointer">
                <input
                  type="checkbox"
                  className="form-checkbox h-5 w-5 text-success rounded focus:ring-success"
                  checked={checklist.practicedEmpathy}
                  onChange={() => handleChecklistChange('practicedEmpathy')}
                />
                <span>I practiced empathy by trying to understand another's perspective.</span>
              </label>
              <label className="flex items-center gap-3 text-gray-900 cursor-pointer">
                <input
                  type="checkbox"
                  className="form-checkbox h-5 w-5 text-success rounded focus:ring-success"
                  checked={checklist.strengthenedConnection}
                  onChange={() => handleChecklistChange('strengthenedConnection')}
                />
                <span>I took a step to strengthen a connection with someone.</span>
              </label>
              <label className="flex items-center gap-3 text-gray-900 cursor-pointer">
                <input
                  type="checkbox"
                  className="form-checkbox h-5 w-5 text-success rounded focus:ring-success"
                  checked={checklist.recognizedInterdependence}
                  onChange={() => handleChecklistChange('recognizedInterdependence')}
                />
                <span>I recognized a moment of interdependence in my daily life.</span>
              </label>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-2xl font-semibold text-gray-900 flex items-center justify-center gap-2">
              <Star className="text-yellow-500" size={28} />
              How connected do you feel to others and the world?
            </h3>
            <div className="flex justify-center gap-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star
                  key={star}
                  className={`cursor-pointer transition-colors duration-200 ${
                    star <= starRating ? 'text-yellow-400 fill-current' : 'text-gray-400'
                  }`}
                  size={40}
                  onClick={() => handleStarClick(star)}
                />
              ))}
            </div>
            <p className="text-sm text-gray-900">
              {starRating > 0 ? `You rated: ${starRating} stars` : 'Click a star to rate'}
            </p>
          </div>

          {submissionStatus === 'success' && (
            <p className="text-success text-center">✅ Submitted successfully!</p>
          )}
          {submissionStatus === 'error' && (
            <p className="text-error text-center">❌ Submission failed. Please try again. Check console for details.</p>
          )}

          <div className="flex justify-between mt-10">
            <button
              type="button"
              onClick={onPrev}
              className="px-6 py-2 rounded-full font-semibold text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 shadow-sm transition-colors"
            >
              Previous
            </button>
            <button
              type="submit"
              className="flex items-center justify-center gap-2 px-6 py-2 rounded-full font-semibold text-white bg-gradient-to-r from-purple-600 to-blue-500 hover:from-purple-700 hover:to-blue-600 shadow-md transition-all"
            >
              Submit & Next <span>→</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Page13_Module4_Practice;
