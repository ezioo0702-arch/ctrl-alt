import React from "react";
import GlareHover from "./GlareHover";
import Link from 'next/link';
interface NavbarProps {
  goToPage: (page: number) => void;
}

export default function Navbar({ goToPage }: NavbarProps) {
  return (
    <nav
      className="
        w-full z-50
        bg-black/20 backdrop-blur-xl
        border-b border-white/10
      "
    >
      <div className="max-w-6xl mx-auto px-6 py-4 flex justify-between items-center">
        
        {/* LEFT — Title with Glare */}
        <GlareHover
          glareColor="#ffffff"
          glareOpacity={0.35}
          glareAngle={-25}
          glareSize={250}
          transitionDuration={700}
          style={{ display: "inline-block" }}
        >
          <h1
            className="text-white font-semibold tracking-wide text-lg cursor-pointer"
            onClick={() => goToPage(1)}
          >
            ctrl+alt+self
          </h1>
        </GlareHover>

        {/* CENTER — Modules with Glare */}
        <div className="hidden md:flex items-center gap-10 text-white/80 text-sm">

          <GlareHover glareColor="#fff" glareOpacity={0.35} glareSize={200} glareAngle={-20}>
            <button
              onClick={() => goToPage(6)}
              className="hover:text-white transition cursor-pointer"
            >
              Module 1
            </button>
          </GlareHover>

          <GlareHover glareColor="#fff" glareOpacity={0.35} glareSize={200} glareAngle={-20}>
            <button
              onClick={() => goToPage(8)}
              className="hover:text-white transition cursor-pointer"
            >
              Module 2
            </button>
          </GlareHover>

          <GlareHover glareColor="#fff" glareOpacity={0.35} glareSize={200} glareAngle={-20}>
            <button
              onClick={() => goToPage(10)}
              className="hover:text-white transition cursor-pointer"
            >
              Module 3
            </button>
          </GlareHover>

          <GlareHover glareColor="#fff" glareOpacity={0.35} glareSize={200} glareAngle={-20}>
            <button
              onClick={() => goToPage(12)}
              className="hover:text-white transition cursor-pointer"
            >
              Module 4
            </button>
          </GlareHover>

        </div>
      </div>
    </nav>
  );
}
