import React, { useState } from 'react';
import Iridescence from './Iridescence';
import { BookOpen, Edit, Quote, Leaf } from 'lucide-react'; // Added Quote and Leaf icons
import saveFormData from '../utils/saveFormData';

interface PageProps {
  onNext: () => void;
  onPrev: () => void;
}

const Page06_Module1_Story: React.FC<PageProps> = ({ onNext, onPrev }) => {
  const [reflectionText, setReflectionText] = useState('');
  const [submissionStatus, setSubmissionStatus] = useState<'success' | 'error' | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmissionStatus(null);

    const success = await saveFormData('module1Reflections', { reflection: reflectionText });

    if (success) {
      setSubmissionStatus('success');
      setReflectionText(''); // Clear form
      setTimeout(() => {
        onNext();
      }, 1000);
    } else {
      setSubmissionStatus('error');
    }
  };

  return (
    <div className="relative min-h-screen w-full overflow-hidden">
      {/* Adjusted Iridescence color and parameters to better match the image's aesthetic */}
      <Iridescence color={[0.85, 0.9, 0.8]} speed={0.8} amplitude={0.07} mouseReact={true} />
      <div className="relative z-10 min-h-screen w-full flex flex-col justify-center items-center text-center p-4 py-12">
        <div className="max-w-3xl mx-auto bg-white rounded-3xl shadow-xl p-8 md:p-12 space-y-8 border border-gray-200"> {/* Adjusted shadow and border */}
          <h2 className="text-4xl font-bold text-gray-800 tracking-tight mb-4 flex items-center justify-center gap-3">
            <Leaf className="text-green-500" size={36} /> {/* Changed icon to Leaf */}
            Module One
          </h2>
          <h1 className="text-4xl font-bold text-gray-800 tracking-tight mb-4">
            The Mandala of Life – Letting Go & Returning to Self
          </h1>

          {/* Philosophy Section */}
          <div className="bg-green-50 border-l-4 border-green-400 p-6 rounded-r-lg text-left flex items-start gap-4 shadow-sm">
            <BookOpen className="text-green-500 flex-shrink-0 mt-1" size={24} /> {/* Adjusted icon and margin */}
            <div>
              <h3 className="font-semibold text-xl text-green-700 mb-2">Philosophy: Impermanence (Anicca)</h3>
              <p className="text-gray-700 leading-relaxed">
                In Buddhist thought, <span className="font-semibold">Anicca</span> reminds us that everything changes — the seasons, our emotions, our roles.
              </p>
              <p className="text-gray-700 italic leading-relaxed mt-2">
                To live well is not to resist change, but to flow with it.
              </p>
            </div>
          </div>

          {/* Story Section */}
          <div className="mt-8">
            <h3 className="text-2xl font-semibold text-gray-800 flex items-center justify-center gap-2 mb-4">
              <BookOpen className="text-blue-500" size={28} />
              Story: The Mandala That Returned to the River
            </h3>
            <p className="text-gray-700 leading-relaxed text-left">
              In a quiet Himalayan valley, a young monk named Tenzin lived among misty mountains and whispering prayer flags. During the Festival of Compassion, he helped create a sacred mandala — a universe made of colored sand.
            </p>
            <p className="text-gray-700 leading-relaxed text-left mt-3">
              When the mandala was complete, it shone like a jewel, and pride filled his heart. But the next morning, the bell tolled — it was time for dissolution.
            </p>

            {/* Quote Box */}
            <blockquote className="bg-yellow-50 border-l-4 border-yellow-400 p-6 rounded-r-lg italic text-gray-700 text-lg my-6 text-left shadow-sm">
              <Quote className="text-yellow-400 inline-block mr-2" size={24} />
              "Master," Tenzin pleaded, "why destroy something so beautiful?"
              <p className="mt-2">Lama Dorje smiled, "Beauty is not meant to be trapped — it is meant to be lived."</p>
            </blockquote>

            <p className="text-gray-700 leading-relaxed text-left mt-3">
              With one sweep, the mandala was erased. Tenzin felt loss — but also release. As the sand flowed into the river, he realized:
            </p>
            <p className="text-center text-green-600 font-bold text-xl italic mt-6 mb-8">
              Nothing beautiful is ever lost; it simply changes place.
            </p>
          </div>

          {/* Moral Section */}
          <div className="bg-blue-50 border-l-4 border-blue-400 p-6 rounded-r-lg text-left flex items-start gap-4 shadow-sm">
            <Leaf className="text-blue-500 flex-shrink-0 mt-1" size={24} /> {/* Changed icon to Leaf */}
            <div>
              <h3 className="font-semibold text-xl text-blue-700 mb-2">Moral</h3>
              <p className="text-gray-700 leading-relaxed">
                True creation lies not in holding on, but in giving your whole heart — and letting go.
              </p>
            </div>
          </div>

          {/* Reflection Section */}
          <form onSubmit={handleSubmit} className="space-y-4 text-left mt-8">
            <h3 className="text-2xl font-semibold text-gray-900 flex items-center gap-2">
              <Edit className="text-purple-500" size={28} />
              Reflection
            </h3>
            <p className="text-gray-700">
              What have you been holding on to so tightly that it's stopping your peace?
            </p>
            <p className="text-gray-700">
              What would happen if you let it go, even a little?
            </p>
            <textarea
              className="w-full p-4 rounded-xl bg-gray-50 border border-gray-300 text-gray-700 placeholder-gray-500 focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200 min-h-[150px]"
              placeholder="Let your thoughts flow freely here..."
              value={reflectionText}
              onChange={(e) => setReflectionText(e.target.value)}
            ></textarea>
            {submissionStatus === 'success' && (
              <p className="text-success text-center">✅ Submitted successfully!</p>
            )}
            {submissionStatus === 'error' && (
              <p className="text-error text-center">❌ Submission failed. Please try again.</p>
            )}
            <div className="flex justify-between mt-10">
              <button
                type="button"
                onClick={onPrev}
                className="px-6 py-2 rounded-full font-semibold text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 shadow-sm transition-colors"
              >
                ← Previous
              </button>
              <button
                type="submit"
                className="flex items-center justify-center gap-2 px-6 py-2 rounded-full font-semibold text-white bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 shadow-md transition-all"
              >
                Next <span>→</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Page06_Module1_Story;
