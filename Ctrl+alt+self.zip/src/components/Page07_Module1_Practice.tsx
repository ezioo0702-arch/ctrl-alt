import React, { useState } from 'react';
import Iridescence from './Iridescence';
import { CheckSquare, Star, Pencil } from 'lucide-react'; // Removed Square, added Pencil for header
import saveFormData from '../utils/saveFormData'; // Import saveFormData
import DrawingCanvas from './DrawingCanvas'; // Import the new DrawingCanvas component

interface PageProps {
  onNext: () => void;
  onPrev: () => void;
}

const Page07_Module1_Practice: React.FC<PageProps> = ({ onNext, onPrev }) => {
  const [starRating, setStarRating] = useState(0);
  const [checklist, setChecklist] = useState({
    recognizedEmotionally: false,
    practicedSymbolicRelease: false,
    feelLighter: false,
  });
  const [attachmentsToRelease, setAttachmentsToRelease] = useState(['', '', '']);
  const [intentionsToInvite, setIntentionsToInvite] = useState(['', '', '']);
  const [submissionStatus, setSubmissionStatus] = useState<'success' | 'error' | null>(null);

  const handleChecklistChange = (item: keyof typeof checklist) => {
    setChecklist((prev) => ({ ...prev, [item]: !prev[item] }));
  };

  const handleAttachmentChange = (index: number, value: string) => {
    const newAttachments = [...attachmentsToRelease];
    newAttachments[index] = value;
    setAttachmentsToRelease(newAttachments);
  };

  const handleIntentionChange = (index: number, value: string) => {
    const newIntentions = [...intentionsToInvite];
    newIntentions[index] = value;
    setIntentionsToInvite(newIntentions);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmissionStatus(null);

    const dataToSave = {
      starRating,
      checklist,
      attachmentsToRelease,
      intentionsToInvite,
      // Note: Drawing canvas data is not saved in this example.
      // For saving, you would convert canvas content to an image (e.g., base64)
      // and include it in dataToSave.
    };

    const success = await saveFormData('module1Practice', dataToSave);

    if (success) {
      setSubmissionStatus('success');
      // Clear form fields
      setStarRating(0);
      setChecklist({
        recognizedEmotionally: false,
        practicedSymbolicRelease: false,
        feelLighter: false,
      });
      setAttachmentsToRelease(['', '', '']);
      setIntentionsToInvite(['', '', '']);
      // Delay navigation to allow success message to be seen
      setTimeout(() => {
        onNext();
      }, 1000); // 1 second delay
    } else {
      setSubmissionStatus('error');
      // Do not navigate on error
    }
  };

  return (
    <div className="relative min-h-screen w-full overflow-hidden">
      <Iridescence color={[0.85, 0.9, 0.8]} speed={0.8} amplitude={0.07} mouseReact={true} />
      <div className="relative z-10 min-h-screen w-full flex flex-col justify-center items-center text-center p-4 py-12">
        <form onSubmit={handleSubmit} className="max-w-3xl mx-auto bg-white rounded-3xl shadow-xl p-8 md:p-12 space-y-8 border border-gray-200">
          <h2 className="text-4xl font-bold text-gray-800 tracking-tight mb-4 flex items-center justify-center gap-3">
            <CheckSquare className="text-green-500" size={36} />
            Module One (Continued)
          </h2>
          <h1 className="text-4xl font-bold text-gray-800 tracking-tight mb-4">
            Practice & Reflection
          </h1>

          {/* Practice Activity Section */}
          <div className="bg-green-50 border-l-4 border-green-400 p-6 rounded-r-lg text-left flex flex-col gap-4 shadow-sm">
            <h3 className="text-2xl font-semibold text-green-700 flex items-center gap-2">
              <Pencil className="text-green-500" size={28} />
              Practice Activity
            </h3>
            <div className="space-y-2">
              <h4 className="font-semibold text-lg text-gray-800">Create Your Mandala</h4>
              <p className="text-gray-700 leading-relaxed">
                Take a moment to draw or visualize a small mandala. Let it represent your current state of being.
              </p>
              {/* Drawing Canvas Integration */}
              <div className="border-2 border-dashed border-gray-400 rounded-lg p-6 h-[300px] flex flex-col items-center justify-center">
                <DrawingCanvas />
              </div>
            </div>
          </div>

          {/* Release & Invite Section */}
          <div className="bg-green-50 border-l-4 border-green-400 p-6 rounded-r-lg text-left flex flex-col gap-4 shadow-sm">
            <h3 className="text-2xl font-semibold text-green-700 flex items-center gap-2">
              <Star className="text-yellow-500" size={28} />
              Release & Invite
            </h3>
            <div className="space-y-2">
              <h4 className="font-semibold text-lg text-gray-800">Three Attachments to Release:</h4>
              {attachmentsToRelease.map((text, index) => (
                <div key={index} className="flex items-center gap-2">
                  <span className="text-gray-700 w-4 text-right">{index + 1}.</span>
                  <textarea
                    className="flex-1 p-2 rounded-md bg-gray-50 border border-gray-300 text-gray-700 placeholder-gray-500 focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200 min-h-[50px]"
                    placeholder="Attachment..."
                    value={text}
                    onChange={(e) => handleAttachmentChange(index, e.target.value)}
                  />
                  <div className="flex flex-col">
                    <button type="button" className="p-1 text-gray-500 hover:text-gray-700"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 15l-6-6-6 6"/></svg></button>
                    <button type="button" className="p-1 text-gray-500 hover:text-gray-700"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M6 9l6 6 6-6"/></svg></button>
                  </div>
                </div>
              ))}
            </div>
            <div className="space-y-2 mt-4">
              <h4 className="font-semibold text-lg text-gray-800">Three Intentions to Invite:</h4>
              {intentionsToInvite.map((text, index) => (
                <div key={index} className="flex items-center gap-2">
                  <span className="text-gray-700 w-4 text-right">{index + 1}.</span>
                  <textarea
                    className="flex-1 p-2 rounded-md bg-gray-50 border border-gray-300 text-gray-700 placeholder-gray-500 focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200 min-h-[50px]"
                    placeholder="Intention..."
                    value={text}
                    onChange={(e) => handleIntentionChange(index, e.target.value)}
                  />
                  <div className="flex flex-col">
                    <button type="button" className="p-1 text-gray-500 hover:text-gray-700"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 15l-6-6-6 6"/></svg></button>
                    <button type="button" className="p-1 text-gray-500 hover:text-gray-700"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M6 9l6 6 6-6"/></svg></button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Evaluation Checklist Section */}
          <div className="bg-green-50 border-l-4 border-green-400 p-6 rounded-r-lg text-left flex flex-col gap-4 shadow-sm">
            <h3 className="text-2xl font-semibold text-green-700 flex items-center gap-2">
              <CheckSquare className="text-success" size={28} />
              Evaluation Checklist
            </h3>
            <p className="text-gray-700">Reflect on your experience with this module:</p>
            <div className="space-y-2">
              <label className="flex items-center gap-3 text-gray-700 cursor-pointer">
                <input
                  type="checkbox"
                  className="form-checkbox h-5 w-5 text-success rounded focus:ring-success border-gray-400"
                  checked={checklist.recognizedEmotionally}
                  onChange={() => handleChecklistChange('recognizedEmotionally')}
                />
                <span>I recognized what I cling to emotionally.</span>
              </label>
              <label className="flex items-center gap-3 text-gray-700 cursor-pointer">
                <input
                  type="checkbox"
                  className="form-checkbox h-5 w-5 text-success rounded focus:ring-success border-gray-400"
                  checked={checklist.practicedSymbolicRelease}
                  onChange={() => handleChecklistChange('practicedSymbolicRelease')}
                />
                <span>I practiced symbolic release.</span>
              </label>
              <label className="flex items-center gap-3 text-gray-700 cursor-pointer">
                <input
                  type="checkbox"
                  className="form-checkbox h-5 w-5 text-success rounded focus:ring-success border-gray-400"
                  checked={checklist.feelLighter}
                  onChange={() => handleChecklistChange('feelLighter')}
                />
                <span>I feel lighter or more accepting after this activity.</span>
              </label>
            </div>
          </div>

          {/* Self-Rating Scale Section */}
          <div className="bg-yellow-50 border-l-4 border-yellow-400 p-6 rounded-r-lg text-left flex flex-col gap-4 shadow-sm">
            <h3 className="text-2xl font-semibold text-yellow-700 flex items-center gap-2">
              <Star className="text-yellow-500" size={28} />
              Self-Rating Scale
            </h3>
            <p className="text-gray-700 italic">"How peaceful do I feel right now?"</p>
            <div className="flex justify-center gap-2 mt-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star
                  key={star}
                  className={`cursor-pointer transition-colors duration-200 ${
                    star <= starRating ? 'text-yellow-400 fill-current' : 'text-gray-400'
                  }`}
                  size={40}
                  onClick={() => setStarRating(star)}
                />
              ))}
            </div>
          </div>

          {submissionStatus === 'success' && (
            <p className="text-success text-center">✅ Submitted successfully!</p>
          )}
          {submissionStatus === 'error' && (
            <p className="text-error text-center">❌ Submission failed. Please try again. Check console for details.</p>
          )}

          <div className="flex justify-between mt-10">
            <button
              type="button"
              onClick={onPrev}
              className="px-6 py-2 rounded-full font-semibold text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 shadow-sm transition-colors flex items-center gap-1"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
              Previous
            </button>
            <button
              type="submit"
              className="flex items-center justify-center gap-2 px-6 py-2 rounded-full font-semibold text-white bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 shadow-md transition-all"
            >
              Next <span>→</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Page07_Module1_Practice;
