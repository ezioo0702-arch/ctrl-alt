import React, { useState } from 'react';
import Iridescence from './Iridescence';
// Corrected import for HeartBroken
import { ThumbsUp, Sparkles, CheckCheck, Heart, Lightbulb } from 'lucide-react';
import saveFormData from '../utils/saveFormData';

// The HeartBroken icon is not directly exported from lucide-react.
// It's usually accessed via the default export or a specific path if it exists.
// For now, we'll remove it and use a placeholder or another icon if needed.
// If HeartBroken is essential, we might need to find an alternative or a different way to import it.

interface PageProps {
  onNext: () => void;
  onPrev: () => void;
}

const Page09_Module2_Practice: React.FC<PageProps> = ({ onNext, onPrev }) => {
  const [formData, setFormData] = useState({
    // Transformation That Hurt
    hurt_describe: '',
    hurt_happened_felt: '',
    hurt_lesson: '',
    hurt_learned: '',
    // Ongoing Transformation
    ongoing_describe: '',
    ongoing_changing: '',
    ongoing_lesson: '',
    ongoing_learning: '',
    // Hoping For Transformation
    hoping_describe: '',
    hoping_wish: '',
    hoping_lesson: '',
    hoping_learn: '',
    // Evaluation Checklist
    eval_reflection_experience: false,
    eval_reflection_stages: false,
    eval_accepted_uncertainty: false,
    eval_identified_effort: false,
    // Trust in the Process
    trust_level: 3, // Default to middle of slider
    trust_quote: '',
  });

  const [submissionStatus, setSubmissionStatus] = useState<'success' | 'error' | null>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmissionStatus(null);

    // Assuming saveFormData can handle an object
    const success = await saveFormData('module2Timeline', formData);

    if (success) {
      setSubmissionStatus('success');
      // Clear form after successful submission
      setFormData({
        hurt_describe: '', hurt_happened_felt: '', hurt_lesson: '', hurt_learned: '',
        ongoing_describe: '', ongoing_changing: '', ongoing_lesson: '', ongoing_learning: '',
        hoping_describe: '', hoping_wish: '', hoping_lesson: '', hoping_learn: '',
        eval_reflection_experience: false, eval_reflection_stages: false,
        eval_accepted_uncertainty: false, eval_identified_effort: false,
        trust_level: 3, trust_quote: '',
      });
      setTimeout(() => {
        onNext();
      }, 1500); // Slightly longer delay for user to see success message
    } else {
      setSubmissionStatus('error');
    }
  };

  const sliderLabels = ['Low', 'Emerging', 'Growing', 'Strong', 'Deep'];

  return (
    <div className="relative min-h-screen w-full overflow-hidden">
      {/* Using a different color for Iridescence for variety */}
      <Iridescence color={[0.5, 0.7, 0.9]} speed={0.7} amplitude={0.06} mouseReact={true} />
      <div className="relative z-10 min-h-screen w-full flex flex-col justify-center items-center text-center p-4 py-12">
        <form onSubmit={handleSubmit} className="max-w-4xl mx-auto bg-white rounded-3xl shadow-xl p-8 md:p-12 space-y-12 border border-gray-200">
          <h2 className="text-3xl font-bold text-gray-800 tracking-tight mb-4 flex items-center justify-center gap-3">
            <Lightbulb className="text-yellow-500" size={36} />
            MODULE TWO (CONTINUED)
          </h2>
          <h1 className="text-4xl font-bold text-gray-800 tracking-tight mb-4">
            Timeline of Change
          </h1>

          {/* Section 1: Practice Activity */}
          <div className="bg-blue-50 border-l-4 border-blue-400 p-6 rounded-r-lg text-left flex flex-col gap-4 shadow-sm">
            <h3 className="text-2xl font-semibold text-blue-700 flex items-center gap-2">
              <ThumbsUp className="text-blue-500" size={28} />
              Practice Activity: Create Your Timeline of Change
            </h3>
            <p className="text-gray-700 leading-relaxed">
              Reflect on the transformations in your life. For each stage, write about the experience and the lesson it carried.
            </p>
          </div>

          {/* Section 2: One Transformation That Hurt */}
          <div className="bg-red-50 border-l-4 border-red-400 p-6 rounded-r-lg text-left flex flex-col gap-4 shadow-sm">
            <h3 className="text-2xl font-semibold text-red-700 flex items-center gap-2">
              {/* Placeholder for HeartBroken icon */}
              <Heart className="text-red-500" size={28} />
              One Transformation That Hurt
            </h3>
            <textarea
              name="hurt_describe"
              className="w-full p-4 rounded-xl bg-gray-50 border border-gray-300 text-gray-700 placeholder-gray-500 focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200 min-h-[100px]"
              placeholder="Describe a change that was painful or difficult."
              value={formData.hurt_describe}
              onChange={handleInputChange}
            ></textarea>
            <textarea
              name="hurt_happened_felt"
              className="w-full p-4 rounded-xl bg-gray-50 border border-gray-300 text-gray-700 placeholder-gray-500 focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200 min-h-[100px]"
              placeholder="What happened? How did it feel?"
              value={formData.hurt_happened_felt}
              onChange={handleInputChange}
            ></textarea>
            <textarea
              name="hurt_lesson"
              className="w-full p-4 rounded-xl bg-gray-50 border border-gray-300 text-gray-700 placeholder-gray-500 focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200 min-h-[100px]"
              placeholder="What lesson did it carry?"
              value={formData.hurt_lesson}
              onChange={handleInputChange}
            ></textarea>
            <textarea
              name="hurt_learned"
              className="w-full p-4 rounded-xl bg-gray-50 border border-gray-300 text-gray-700 placeholder-gray-500 focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200 min-h-[100px]"
              placeholder="What did you learn from this experience?"
              value={formData.hurt_learned}
              onChange={handleInputChange}
            ></textarea>
          </div>

          {/* Section 3: One That's Ongoing */}
          <div className="bg-green-50 border-l-4 border-green-400 p-6 rounded-r-lg text-left flex flex-col gap-4 shadow-sm">
            <h3 className="text-2xl font-semibold text-green-700 flex items-center gap-2">
              {/* Removed Seedling from import and using a placeholder icon */}
              <Heart className="text-green-500" size={28} />
              One That's Ongoing
            </h3>
            <textarea
              name="ongoing_describe"
              className="w-full p-4 rounded-xl bg-gray-50 border border-gray-300 text-gray-700 placeholder-gray-500 focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200 min-h-[100px]"
              placeholder="Describe a transformation you're currently experiencing."
              value={formData.ongoing_describe}
              onChange={handleInputChange}
            ></textarea>
            <textarea
              name="ongoing_changing"
              className="w-full p-4 rounded-xl bg-gray-50 border border-gray-300 text-gray-700 placeholder-gray-500 focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200 min-h-[100px]"
              placeholder="What's changing in your life right now?"
              value={formData.ongoing_changing}
              onChange={handleInputChange}
            ></textarea>
            <textarea
              name="ongoing_lesson"
              className="w-full p-4 rounded-xl bg-gray-50 border border-gray-300 text-gray-700 placeholder-gray-500 focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200 min-h-[100px]"
              placeholder="What lesson is it carrying?"
              value={formData.ongoing_lesson}
              onChange={handleInputChange}
            ></textarea>
            <textarea
              name="ongoing_learning"
              className="w-full p-4 rounded-xl bg-gray-50 border border-gray-300 text-gray-700 placeholder-gray-500 focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200 min-h-[100px]"
              placeholder="What are you learning as you go through this?"
              value={formData.ongoing_learning}
              onChange={handleInputChange}
            ></textarea>
          </div>

          {/* Section 4: One You're Hoping For */}
          <div className="bg-purple-50 border-l-4 border-purple-400 p-6 rounded-r-lg text-left flex flex-col gap-4 shadow-sm">
            <h3 className="text-2xl font-semibold text-purple-700 flex items-center gap-2">
              <Sparkles className="text-purple-500" size={28} />
              One You're Hoping For
            </h3>
            <textarea
              name="hoping_describe"
              className="w-full p-4 rounded-xl bg-gray-50 border border-gray-300 text-gray-700 placeholder-gray-500 focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200 min-h-[100px]"
              placeholder="Describe a change you're hoping will come."
              value={formData.hoping_describe}
              onChange={handleInputChange}
            ></textarea>
            <textarea
              name="hoping_wish"
              className="w-full p-4 rounded-xl bg-gray-50 border border-gray-300 text-gray-700 placeholder-gray-500 focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200 min-h-[100px]"
              placeholder="What transformation do you wish for?"
              value={formData.hoping_wish}
              onChange={handleInputChange}
            ></textarea>
            <textarea
              name="hoping_lesson"
              className="w-full p-4 rounded-xl bg-gray-50 border border-gray-300 text-gray-700 placeholder-gray-500 focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200 min-h-[100px]"
              placeholder="What lesson might it carry?"
              value={formData.hoping_lesson}
              onChange={handleInputChange}
            ></textarea>
            <textarea
              name="hoping_learn"
              className="w-full p-4 rounded-xl bg-gray-50 border border-gray-300 text-gray-700 placeholder-gray-500 focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200 min-h-[100px]"
              placeholder="What do you hope to learn from this future change?"
              value={formData.hoping_learn}
              onChange={handleInputChange}
            ></textarea>
          </div>

          {/* Section 5: Evaluation Checklist */}
          <div className="bg-yellow-50 border-l-4 border-yellow-400 p-6 rounded-r-lg text-left flex flex-col gap-4 shadow-sm">
            <h3 className="text-2xl font-semibold text-yellow-700 flex items-center gap-2">
              <CheckCheck className="text-yellow-500" size={28} />
              Evaluation Checklist
            </h3>
            <div className="space-y-3">
              <label className="flex items-center gap-3 text-gray-700 cursor-pointer">
                <input
                  type="checkbox"
                  name="eval_reflection_experience"
                  className="form-checkbox h-5 w-5 text-yellow-500 rounded focus:ring-yellow-500 border-gray-300"
                  checked={formData.eval_reflection_experience}
                  onChange={handleInputChange}
                />
                <span>I reflected on experience with this module.</span>
              </label>
              <label className="flex items-center gap-3 text-gray-700 cursor-pointer">
                <input
                  type="checkbox"
                  name="eval_reflection_stages"
                  className="form-checkbox h-5 w-5 text-yellow-500 rounded focus:ring-yellow-500 border-gray-300"
                  checked={formData.eval_reflection_stages}
                  onChange={handleInputChange}
                />
                <span>I reflected on change through my life stages.</span>
              </label>
              <label className="flex items-center gap-3 text-gray-700 cursor-pointer">
                <input
                  type="checkbox"
                  name="eval_accepted_uncertainty"
                  className="form-checkbox h-5 w-5 text-yellow-500 rounded focus:ring-yellow-500 border-gray-300"
                  checked={formData.eval_accepted_uncertainty}
                  onChange={handleInputChange}
                />
                <span>I accepted uncertainty as growth.</span>
              </label>
              <label className="flex items-center gap-3 text-gray-700 cursor-pointer">
                <input
                  type="checkbox"
                  name="eval_identified_effort"
                  className="form-checkbox h-5 w-5 text-yellow-500 rounded focus:ring-yellow-500 border-gray-300"
                  checked={formData.eval_identified_effort}
                  onChange={handleInputChange}
                />
                <span>I identified effort as my source of meaning.</span>
              </label>
            </div>
          </div>

          {/* Section 6: Trust in the Process */}
          <div className="bg-pink-50 border-l-4 border-pink-400 p-6 rounded-r-lg text-left flex flex-col gap-4 shadow-sm">
            <h3 className="text-2xl font-semibold text-pink-700 flex items-center gap-2">
              <Heart className="text-pink-500" size={28} />
              Trust in the Process
            </h3>
            <p className="text-gray-700">
              My trust in the process feels...
            </p>
            <div className="relative w-full">
              <input
                type="range"
                name="trust_level"
                min="0"
                max={sliderLabels.length - 1}
                step="1"
                value={formData.trust_level}
                onChange={handleInputChange}
                className="w-full h-2 bg-gray-300 rounded-lg appearance-none cursor-pointer accent-pink-500"
              />
              <div className="flex justify-between text-sm text-gray-600 mt-2">
                {sliderLabels.map((label, index) => (
                  <span
                    key={label}
                    className={`absolute top-full transform -translate-x-1/2 ${
                      index === 0 ? 'left-0' : index === sliderLabels.length - 1 ? 'right-0 -translate-x-0' : `left-${(index * 100) / (sliderLabels.length - 1)}%`
                    }`}
                    style={{ left: `${(index * 100) / (sliderLabels.length - 1)}%` }}
                  >
                    {label}
                  </span>
                ))}
              </div>
            </div>
            <p className="text-sm text-gray-600 mt-8">
              Move the slider to reflect your current trust level.
            </p>
            {/* Optional: Add a textarea for the quote if needed, or just display the slider value */}
            {/* <textarea
              name="trust_quote"
              className="w-full p-4 rounded-xl bg-gray-50 border border-gray-300 text-gray-700 placeholder-gray-500 focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200 min-h-[100px]"
              placeholder="Add any further thoughts on your trust level..."
              value={formData.trust_quote}
              onChange={handleInputChange}
            ></textarea> */}
          </div>

          {submissionStatus === 'success' && (
            <p className="text-success text-center text-lg font-semibold">✅ Submitted successfully!</p>
          )}
          {submissionStatus === 'error' && (
            <p className="text-error text-center text-lg font-semibold">❌ Submission failed. Please try again.</p>
          )}

          <div className="flex justify-between mt-10">
            <button
              type="button"
              onClick={onPrev}
              className="px-6 py-2 rounded-full font-semibold text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 shadow-sm transition-colors flex items-center gap-1"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
              Previous
            </button>
            <button
              type="submit"
              className="flex items-center justify-center gap-2 px-6 py-2 rounded-full font-semibold text-white bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 shadow-md transition-all"
            >
              Next <span>→</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Page09_Module2_Practice;
