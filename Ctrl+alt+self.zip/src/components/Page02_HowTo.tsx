import React from 'react';
import Iridescence from './Iridescence'; // Import Iridescence component

// Define the props interface
interface PageProps {
  onNext: () => void;
  onPrev: () => void;
}

const Page02_HowTo: React.FC<PageProps> = ({ onNext, onPrev }) => {
  return (
    // We add a relative container for the Iridescence background
    <div className="relative min-h-screen w-full overflow-hidden">
      <Iridescence color={[0.62, 0.5, 1.0]} speed={0.8} amplitude={0.05} mouseReact={true} />

      {/* This is the main content wrapper, now positioned above the background */}
      <div className="relative z-10 min-h-screen w-full flex justify-center items-center p-4 py-12">

        {/* This is the main white content card, styled like Flowline */}
        <div className="bg-white w-full max-w-3xl rounded-2xl shadow-xl p-8 md:p-12">

          <div className="text-center mb-8">
            <p className="text-sm font-medium text-gray-900">GETTING STARTED</p>
            <h2 className="text-3xl font-bold text-gray-900 mt-1">
              How to Navigate This Course
            </h2>
          </div>

          <p className="text-center text-gray-900 mb-8">
            This interactive journey is designed to guide you gently through self-discovery. Here's how to make the most of your experience.
          </p>

          {/* Section 1: 2x2 Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-start space-x-3">
              <span className="text-2xl" role="img" aria-label="book">📖</span>
              <div>
                <h3 className="font-semibold text-gray-900">Story</h3>
                <p className="text-sm text-gray-900">Each module begins with a philosophical story that illuminates a key concept.</p>
              </div>
            </div>
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-start space-x-3">
              <span className="text-2xl" role="img" aria-label="leaf">🌿</span>
              <div>
                <h3 className="font-semibold text-gray-900">Reflection</h3>
                <p className="text-sm text-gray-900">Pause and write your thoughts in the reflection boxes provided.</p>
              </div>
            </div>
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-start space-x-3">
              <span className="text-2xl" role="img" aria-label="flower">🌸</span>
              <div>
                <h3 className="font-semibold text-gray-900">Practice</h3>
                <p className="text-sm text-gray-900">Engage with creative activities that deepen your understanding.</p>
              </div>
            </div>
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-start space-x-3">
              <span className="text-2xl" role="img" aria-label="star">⭐</span>
              <div>
                <h3 className="font-semibold text-gray-900">Evaluation</h3>
                <p className="text-sm text-gray-900">Track your growth with simple self-assessment checklists.</p>
              </div>
            </div>
          </div>

          {/* Section 2: Your Journey Path (Vertical Timeline) */}
          <div className="bg-green-100 border border-green-300 rounded-lg p-6 mb-8">
            <h3 className="font-semibold text-gray-900 mb-4">Your Journey Path</h3>
            <div className="relative pl-6"> {/* Added relative and padding for timeline */}
              <div className="absolute left-0 top-0 bottom-0 w-0.5 bg-green-300"></div> {/* Vertical line */}
              <ul className="space-y-6"> {/* Increased space-y for better separation */}
                <li className="relative flex items-start">
                  <span className="absolute -left-3 top-0.5 flex h-6 w-6 items-center justify-center rounded-full bg-green-500 text-white text-xs font-bold" role="img" aria-label="right arrow">➡️</span> {/* Icon dot */}
                  <div className="ml-4"> {/* Content shifted right */}
                    <h4 className="font-semibold text-gray-900">Click through each module</h4>
                    <p className="text-sm text-gray-700">Use the 'Next' button to move through stories and activities at your own pace.</p>
                  </div>
                </li>
                <li className="relative flex items-start">
                  <span className="absolute -left-3 top-0.5 flex h-6 w-6 items-center justify-center rounded-full bg-green-500 text-white text-xs font-bold" role="img" aria-label="writing hand">✍️</span>
                  <div className="ml-4">
                    <h4 className="font-semibold text-gray-900">Reflect after every story</h4>
                    <p className="text-sm text-gray-700">Take your time with the reflection boxes — there are no wrong answers.</p>
                  </div>
                </li>
                <li className="relative flex items-start">
                  <span className="absolute -left-3 top-0.5 flex h-6 w-6 items-center justify-center rounded-full bg-green-500 text-white text-xs font-bold" role="img" aria-label="leaf">🌿</span>
                  <div className="ml-4">
                    <h4 className="font-semibold text-gray-900">Complete evaluation checklists</h4>
                    <p className="text-sm text-gray-700">Self-track your growth with simple checkboxes and rating scales.</p>
                  </div>
                </li>
                <li className="relative flex items-start">
                  <span className="absolute -left-3 top-0.5 flex h-6 w-6 items-center justify-center rounded-full bg-green-500 text-white text-xs font-bold" role="img" aria-label="sparkles">✨</span>
                  <div className="ml-4">
                    <h4 className="font-semibold text-gray-900">Craft your Manifesto of Light</h4>
                    <p className="text-sm text-gray-700">At the end, create your personalized reflection of growth and transformation.</p>
                  </div>
                </li>
              </ul>
            </div>
          </div>

          {/* Section 3: Tips Card */}
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 mb-8">
            <h3 className="font-semibold text-gray-900 mb-4">Tips for Your Journey</h3>
            <ul className="space-y-2">
              <li className="flex items-start"><span className="text-yellow-700 mr-2">→</span><span className="text-sm text-gray-900"><b>Take your time</b> — this is not a race, it's a journey inward.</span></li>
              <li className="flex items-start"><span className="text-yellow-700 mr-2">→</span><span className="text-sm text-gray-900"><b>Be honest</b> — your reflections are for you, not for judgment.</span></li>
              <li className="flex items-start"><span className="text-yellow-700 mr-2">→</span><span className="text-sm text-gray-900"><b>Return when needed</b> — you can revisit any module at any time.</span></li>
              <li className="flex items-start"><span className="text-yellow-700 mr-2">→</span><span className="text-sm text-gray-900"><b>Trust the process</b> — transformation happens in small, gentle steps.</span></li>
            </ul>
          </div>

          <p className="text-center text-gray-900 font-medium">Ready to begin your transformation? <br /> Click 'Next' to start your journey 💖</p>

          {/* Navigation Buttons */}
          <div className="flex justify-between mt-10">
            <button
              onClick={onPrev}
              className="px-6 py-2 rounded-full font-semibold text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 shadow-sm transition-colors"
            >
              Previous
            </button>
            <button
              onClick={onNext}
              className="flex items-center justify-center gap-2 px-6 py-2 rounded-full font-semibold text-white bg-gradient-to-r from-purple-600 to-blue-500 hover:from-purple-700 hover:to-blue-600 shadow-md transition-all"
            >
              Next <span>→</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Page02_HowTo;
