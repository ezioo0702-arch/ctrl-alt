import React, { useState } from 'react';
import Iridescence from './Iridescence';
import { CheckSquare, Star, Leaf, Feather, Edit2, Lightbulb, Sparkles } from 'lucide-react'; // Added Sparkles
import saveFormData from '../utils/saveFormData';

interface PageProps {
  onNext: () => void;
  onPrev: () => void;
}

const Page11_Module3_Practice: React.FC<PageProps> = ({ onNext, onPrev }) => {
  const [observationText, setObservationText] = useState('');
  const [completionText, setCompletionText] = useState('');
  const [balanceRating, setBalanceRating] = useState(0);
  const [checklist, setChecklist] = useState({
    recognizedEmotions: false,
    expressedMetaphor: false,
    feltCalmer: false,
  });
  const [submissionStatus, setSubmissionStatus] = useState<'success' | 'error' | null>(null);

  const handleBalanceRatingClick = (rating: number) => {
    setBalanceRating(rating);
  };

  const handleChecklistChange = (item: keyof typeof checklist) => {
    setChecklist((prev) => ({ ...prev, [item]: !prev[item] }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmissionStatus(null);

    const dataToSave = {
      observation: observationText,
      completion: completionText,
      balanceRating,
      checklist,
    };

    const success = await saveFormData('module3NatureObservation', dataToSave);

    if (success) {
      setSubmissionStatus('success');
      setObservationText('');
      setCompletionText('');
      setBalanceRating(0);
      setChecklist({
        recognizedEmotions: false,
        expressedMetaphor: false,
        feltCalmer: false,
      });
      setTimeout(() => {
        onNext();
      }, 1000);
    } else {
      setSubmissionStatus('error');
    }
  };

  return (
    <div className="relative min-h-screen w-full overflow-hidden">
      {/* Adjusted Iridescence color for Module 3 */}
      <Iridescence color={[0.7, 0.5, 0.9]} speed={0.6} amplitude={0.08} mouseReact={true} />
      <div className="relative z-10 min-h-screen w-full flex flex-col justify-center items-center text-center p-4 py-12">
        <form onSubmit={handleSubmit} className="max-w-3xl mx-auto bg-white rounded-3xl shadow-2xl p-8 md:p-12 space-y-8 border border-border">
          
          {/* Header and Title */}
          <div className="text-center mb-8">
            <h2 className="text-4xl font-bold text-gray-900 tracking-tight mb-2 flex items-center justify-center gap-3">
              <Lightbulb className="text-purple-500" size={36} />
              MODULE THREE (CONTINUED)
            </h2>
            <h1 className="text-5xl font-extrabold text-gray-900 leading-tight">
              Nature Observation & Balance
            </h1>
          </div>

          {/* Section 1: Practice Activity */}
          <div className="bg-green-100 p-6 rounded-xl text-left flex flex-col gap-4 shadow-sm border-l-4 border-green-400">
            <h3 className="text-2xl font-semibold text-green-800 flex items-center gap-2">
              <Feather className="text-green-500" size={30} /> {/* Using Feather for nature */}
              Practice Activity
            </h3>

            <div className="space-y-3">
              <h4 className="text-xl font-bold text-gray-800">Spend 5 Minutes in Nature</h4>
              <p className="text-gray-800 leading-relaxed text-lg">
                Find a quiet moment to observe the natural world around you. Notice the breeze, the leaves, the sky, the sounds.
              </p>
            </div>

            <div className="space-y-3">
              <h4 className="text-xl font-bold text-gray-800 flex items-center gap-2">
                <Edit2 className="text-gray-600" size={24} />
                What did you observe?
              </h4>
              <textarea
                className="w-full p-4 rounded-xl bg-white border border-gray-300 text-gray-900 placeholder-gray-500 focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200 min-h-[120px]"
                placeholder="Describe what you noticed — the breeze, leaves, sky, sounds, sensations..."
                value={observationText}
                onChange={(e) => setObservationText(e.target.value)}
              ></textarea>
            </div>

            <div className="space-y-3">
              <h4 className="text-xl font-bold text-gray-800 flex items-center gap-2">
                <Sparkles className="text-yellow-500" size={24} />
                Complete this sentence:
              </h4>
              <p className="text-gray-800 leading-relaxed text-lg italic">
                "Nature teaches me that balance means..."
              </p>
              <textarea
                className="w-full p-4 rounded-xl bg-white border border-gray-300 text-gray-900 placeholder-gray-500 focus:ring-2 focus:ring-yellow-500 focus:border-transparent transition-all duration-200 min-h-[120px]"
                placeholder="What wisdom did nature share with you about balance?"
                value={completionText}
                onChange={(e) => setCompletionText(e.target.value)}
              ></textarea>
            </div>
          </div>

          {/* Section 2: Evaluation Checklist */}
          <div className="text-left space-y-4">
            <h3 className="text-3xl font-bold text-gray-800 flex items-center gap-3">
              <CheckSquare className="text-blue-600" size={32} />
              Evaluation Checklist
            </h3>
            <p className="text-gray-700 leading-relaxed text-lg">
              Reflect on your experience with this module:
            </p>
            <div className="space-y-2">
              <label className="flex items-center gap-3 text-gray-800 cursor-pointer">
                <input
                  type="checkbox"
                  className="form-checkbox h-5 w-5 text-blue-500 rounded focus:ring-blue-500"
                  checked={checklist.recognizedEmotions}
                  onChange={() => handleChecklistChange('recognizedEmotions')}
                />
                <span>I recognized emotions I was resisting.</span>
              </label>
              <label className="flex items-center gap-3 text-gray-800 cursor-pointer">
                <input
                  type="checkbox"
                  className="form-checkbox h-5 w-5 text-blue-500 rounded focus:ring-blue-500"
                  checked={checklist.expressedMetaphor}
                  onChange={() => handleChecklistChange('expressedMetaphor')}
                />
                <span>I expressed my insight using a metaphor from nature.</span>
              </label>
              <label className="flex items-center gap-3 text-gray-800 cursor-pointer">
                <input
                  type="checkbox"
                  className="form-checkbox h-5 w-5 text-blue-500 rounded focus:ring-blue-500"
                  checked={checklist.feltCalmer}
                  onChange={() => handleChecklistChange('feltCalmer')}
                />
                <span>I felt calmer after observation.</span>
              </label>
            </div>
          </div>

          {/* Section 3: Balance Rating Scale */}
          <div className="text-center space-y-4">
            <h3 className="text-3xl font-bold text-gray-800 flex items-center justify-center gap-3">
              <Leaf className="text-green-500" size={32} />
              Balance Rating Scale
            </h3>
            <p className="text-gray-700 leading-relaxed text-lg italic">
              "How balanced do I feel today?"
            </p>
            <div className="flex justify-center gap-3">
              {[1, 2, 3, 4, 5].map((star) => (
                <Leaf
                  key={star}
                  className={`cursor-pointer transition-colors duration-200 ${
                    star <= balanceRating ? 'text-green-400 fill-current' : 'text-gray-400'
                  }`}
                  size={40}
                  onClick={() => handleBalanceRatingClick(star)}
                />
              ))}
            </div>
            <p className="text-sm text-gray-700">
              {balanceRating > 0 ? `You rated: ${balanceRating} out of 5` : 'Click a leaf to rate'}
            </p>
          </div>

          {submissionStatus === 'success' && (
            <p className="text-success text-center">✅ Submitted successfully!</p>
          )}
          {submissionStatus === 'error' && (
            <p className="text-error text-center">❌ Submission failed. Please try again.</p>
          )}

          <div className="flex justify-between mt-10">
            <button
              type="button"
              onClick={onPrev}
              className="px-6 py-2 rounded-full font-semibold text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 shadow-sm transition-colors"
            >
              Previous
            </button>
            <button
              type="submit"
              className="flex items-center justify-center gap-2 px-6 py-2 rounded-full font-semibold text-white bg-gradient-to-r from-purple-600 to-indigo-500 hover:from-purple-700 hover:to-indigo-600 shadow-md transition-all"
            >
              Submit & Next <span>→</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Page11_Module3_Practice;
