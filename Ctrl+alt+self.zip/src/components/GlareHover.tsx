// src/components/GlareHover.tsx

import { useRef } from "react";

const GlareHover = ({
  background = "transparent",
  children,
  glareColor = "#ffffff",
  glareOpacity = 0.5,
  glareAngle = -45,
  glareSize = 250,
  transitionDuration = 650,
  playOnce = false,
  className = "",
  style = {}
}) => {
  const hex = glareColor.replace("#", "");
  let rgba = glareColor;

  if (/^[\dA-Fa-f]{6}$/.test(hex)) {
    rgba = `rgba(${parseInt(hex.slice(0, 2), 16)}, ${parseInt(hex.slice(2, 4), 16)}, ${parseInt(hex.slice(4, 6), 16)}, ${glareOpacity})`;
  }

  const overlayRef = useRef(null);

  const animateIn = () => {
    const el = overlayRef.current;
    if (!el) return;

    el.style.transition = "none";
    el.style.backgroundPosition = "-150% -150%";
    el.style.transition = `${transitionDuration}ms ease`;
    el.style.backgroundPosition = "150% 150%";
  };

  const animateOut = () => {
    const el = overlayRef.current;
    if (!el) return;

    if (playOnce) {
      el.style.transition = "none";
      el.style.backgroundPosition = "-150% -150%";
    } else {
      el.style.transition = `${transitionDuration}ms ease`;
      el.style.backgroundPosition = "-150% -150%";
    }
  };

  const overlayStyle = {
    position: "absolute",
    inset: "-40%",
    background: `linear-gradient(${glareAngle}deg,
      hsla(0,0%,0%,0) 60%,
      ${rgba} 70%,
      hsla(0,0%,0%,0) 100%)`,
    backgroundSize: `${glareSize}% ${glareSize}%`,
    backgroundRepeat: "no-repeat",
    backgroundPosition: "-150% -150%",
    pointerEvents: "none"
  };

  return (
    <span
      className={`relative inline-block overflow-hidden cursor-pointer ${className}`}
      style={{ background, ...style }}
      onMouseEnter={animateIn}
      onMouseLeave={animateOut}
    >
      <span ref={overlayRef} style={overlayStyle} />
      {children}
    </span>
  );
};

export default GlareHover;
