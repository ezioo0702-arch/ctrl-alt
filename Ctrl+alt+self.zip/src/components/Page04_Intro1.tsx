import React, { useState } from 'react';
import Iridescence from './Iridescence';
import { Lightbulb, Sun, Star } from 'lucide-react';

interface PageProps {
  onNext: () => void;
  onPrev: () => void;
}

const Page04_Intro1: React.FC<PageProps> = ({ onNext, onPrev }) => {
  const [rating, setRating] = useState(0);

  return (
    <div className="relative min-h-screen w-full overflow-hidden">
      <Iridescence color={[0.7, 0.6, 0.8]} speed={1.1} amplitude={0.07} mouseReact={true} />
      <div className="relative z-10 min-h-screen w-full flex flex-col justify-center items-center text-center p-4 py-12">
        <div className="max-w-3xl mx-auto bg-white rounded-3xl shadow-2xl p-8 md:p-12 space-y-8 border border-border">
          <p className="text-sm font-medium text-gray-900">INTRODUCTION</p>
          <h2 className="text-4xl font-bold text-gray-900 tracking-tight mb-4">
            The Return to the Self
          </h2>
          <p className="text-lg text-gray-900 leading-relaxed">
            In a world that constantly asks us to do more, know more, be more, this course invites you to pause, reflect, and remember.
          </p>
          <p className="text-lg text-gray-900 leading-relaxed">
            This interactive eBook invites educators, counsellors, and learners to explore self-awareness through Eastern and Western philosophies. Each module combines stories, guided reflections, and creative practices — leading toward a living manifesto of light.
          </p>

          <blockquote className="border-l-4 border-purple-500 pl-4 italic text-gray-700 text-xl my-6">
            "The journey of a thousand miles begins with a single step of awareness."
          </blockquote>

          <p className="text-lg text-gray-900 leading-relaxed">
            This eBook is designed for educators, counsellors, B.Ed. students, and senior school learners who seek not just knowledge, but transformation. It's a space where philosophy meets practice, where ancient wisdom converges with modern challenges.
          </p>

          <div className="grid grid-cols-1 gap-6 mt-8">
            {/* Section 1: Reflection Space */}
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-6 text-left flex flex-col items-start gap-4">
              <Lightbulb className="text-yellow-600 flex-shrink-0" size={32} />
              <div>
                <h3 className="font-semibold text-xl text-gray-900 mb-2">Reflection Space</h3>
                <p className="text-gray-900 text-sm mb-3">
                  What does 'home' mean to you — within yourself?
                </p>
                <textarea
                  className="w-full p-3 border border-amber-300 rounded-lg bg-white text-gray-900 focus:ring-2 focus:ring-amber-400 focus:border-transparent transition-all"
                  rows={5}
                  placeholder="Take your time... let your thoughts flow here..."
                ></textarea>
              </div>
            </div>

            {/* Section 2: Self-Awareness Evaluation */}
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-6 text-left flex flex-col items-start gap-4">
              <Sun className="text-orange-500 flex-shrink-0" size={32} />
              <div>
                <h3 className="font-semibold text-xl text-gray-900 mb-2">Self-Awareness Evaluation</h3>
                <p className="text-gray-900 text-sm mb-3">
                  Rate your current self-awareness:
                </p>
                <div className="flex space-x-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className={`cursor-pointer transition-colors ${
                        star <= rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'
                      }`}
                      size={28}
                      onClick={() => setRating(star)}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-between mt-10">
            <button
              onClick={onPrev}
              className="px-6 py-2 rounded-full font-semibold text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 shadow-sm transition-colors"
            >
              Previous
            </button>
            <button
              onClick={onNext}
              className="flex items-center justify-center gap-2 px-6 py-2 rounded-full font-semibold text-white bg-gradient-to-r from-purple-600 to-blue-500 hover:from-purple-700 hover:to-blue-600 shadow-md transition-all"
            >
              Next <span>→</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Page04_Intro1;
