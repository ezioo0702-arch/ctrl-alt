import React, { useState } from 'react';
import Iridescence from './Iridescence';
import { BookOpen, Edit, Lightbulb, Feather, Leaf, CheckSquare, Star, Edit2, Sparkles, BookMarked, Waves, MousePointerClick, MessageCircle, Rabbit } from 'lucide-react';
import saveFormData from '../utils/saveFormData';

interface PageProps {
  onNext: () => void;
  onPrev: () => void;
}

const Page12_Module4_Story: React.FC<PageProps> = ({ onNext, onPrev }) => {
  const [reflectionText, setReflectionText] = useState('');
  const [submissionStatus, setSubmissionStatus] = useState<'success' | 'error' | null>(null);
  const [isRatatouilleHovered, setIsRatatouilleHovered] = useState(false);
  const [isSoulHovered, setIsSoulHovered] = useState(false); // New state for Soul hover effect

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmissionStatus(null);

    const success = await saveFormData('module4Reflections', { reflection: reflectionText });

    if (success) {
      setSubmissionStatus('success');
      setReflectionText(''); // Clear form
      setTimeout(() => {
        onNext();
      }, 1000);
    } else {
      setSubmissionStatus('error');
    }
  };

  return (
    <div className="relative min-h-screen w-full overflow-hidden">
      <Iridescence color={[0.7, 0.8, 0.6]} speed={0.9} amplitude={0.06} mouseReact={true} />
      <div className="relative z-10 min-h-screen w-full flex flex-col justify-center items-center text-center p-4 py-12">
        
        {/* Main White Card Container */}
        <div className="bg-white w-full max-w-4xl rounded-3xl shadow-2xl p-8 md:p-12 flex flex-col gap-8">

          {/* Header and Title */}
          <div className="text-center mb-4">
            <h2 className="text-4xl font-bold text-gray-900 tracking-tight mb-2 flex items-center justify-center gap-3">
              <Lightbulb className="text-purple-500" size={36} />
              MODULE FOUR
            </h2>
            <h1 className="text-5xl font-extrabold text-gray-900 leading-tight">
              Connection, Flow & Purpose – The Ocean You’re Already In
            </h1>
          </div>

          {/* Philosophy Section (Light Blue Background) */}
          <div className="p-8 space-y-6 bg-blue-100 rounded-xl border border-blue-200">
            <h3 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
              <BookMarked className="text-blue-500" size={36} />
              Philosophy: Wu Wei, Atman, and Ikigai
            </h3>
            <p className="text-lg text-gray-800 leading-relaxed">
              <strong>Wu Wei</strong> (Taoism) teaches effortless action.
            </p>
            <p className="text-lg text-gray-800 leading-relaxed">
              Vedanta speaks of <strong>Atman</strong> — the True Self.
            </p>
            <p className="text-lg text-gray-800 leading-relaxed">
              <strong>Ikigai</strong> reminds us that purpose lies where joy meets usefulness.
            </p>
          </div>

          {/* Story Section (Plain Text) */}
          <div className="p-8 space-y-6">
            <h3 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
              <BookOpen className="text-green-500" size={36} /> {/* Changed icon to BookOpen */}
              Story: The Dancer Who Forgot to Dance
            </h3>
            <p className="text-lg text-gray-800 leading-relaxed">
              Leela, a classical dancer admired for her precision, began losing joy in her art.
            </p>
            <p className="text-lg text-gray-800 leading-relaxed">
              One day while teaching, she saw a child spinning freely — laughing, unafraid of mistakes.
            </p>
            <p className="text-lg text-gray-800 leading-relaxed">
              Leela joined her. No audience. No mirrors. Only joy.
            </p>
          </div>

          {/* Highlight Quote (Light Blue Background) */}
          <div className="p-8 text-center bg-blue-100 rounded-xl border border-blue-200">
            <p className="text-2xl italic text-gray-700 font-semibold">
              *In that moment, her dance returned to her.*
            </p>
          </div>

          {/* Moral Section (Light Blue Background) */}
          <div className="p-8 space-y-4 text-center bg-blue-100 rounded-xl border border-blue-200">
            <h3 className="text-3xl font-bold text-gray-900 flex items-center justify-center gap-3">
              <Waves className="text-blue-500" size={36} />
              Moral
            </h3>
            <p className="text-lg text-gray-800 leading-relaxed">
              Flow begins when striving ends.
            </p>
          </div>

          {/* Film Reflections Title */}
          <div className="p-8 text-center">
            <h3 className="text-4xl font-bold text-gray-900 flex items-center justify-center gap-3">
              <BookMarked className="text-purple-500" size={36} />
              Film Reflections
            </h3>
          </div>

          {/* Film Reflections Cards (Light Blue Backgrounds) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Left Card - Ratatouille with Hover Effect */}
            <div
              className="relative p-8 bg-blue-100 rounded-xl border border-blue-200 overflow-hidden"
            >
              {/* Background Image Overlay */}
              <div
                className={`absolute inset-0 bg-cover bg-center transition-opacity duration-300 ${
                  isRatatouilleHovered ? 'opacity-10' : 'opacity-0' // 10% opacity for subtle watermark
                }`}
                style={{
                  backgroundImage: `url('https://wallpapercat.com/w/full/d/1/d/50452-1920x1200-desktop-hd-ratatouille-wallpaper.jpg')`,
                }}
              ></div>

              {/* Card Content - ensure it's above the background image */}
              <div className="relative z-10 space-y-4">
                <div className="flex items-center gap-3">
                  <Rabbit className="text-red-500" size={36} /> {/* Ratatouille Icon */}
                  <h4 className="text-2xl font-bold text-gray-900">Ratatouille (2007)</h4>
                </div>
                <p className="text-lg italic text-gray-700 font-semibold">
                  *"Creation itself is sacred."*
                </p>
                <p className="text-sm text-gray-500 font-medium">Watch the scene:</p>
                <a
                  href="https://sflix2.to/watch-movie/free-ratatouille-hd-19398.5297938"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex px-6 py-2 rounded-full font-semibold text-white bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-600 hover:to-orange-600 shadow-md transition-all"
                  onMouseEnter={() => setIsRatatouilleHovered(true)} // Trigger hover state
                  onMouseLeave={() => setIsRatatouilleHovered(false)} // Reset hover state
                >
                  Watch Now →
                </a>
              </div>
            </div>

            {/* Right Card - Soul with Hover Effect */}
            <div
              className="relative p-8 bg-blue-100 rounded-xl border border-blue-200 overflow-hidden"
            >
              {/* Background Image Overlay */}
              <div
                className={`absolute inset-0 bg-cover bg-center transition-opacity duration-300 ${
                  isSoulHovered ? 'opacity-10' : 'opacity-0' // 10% opacity for subtle watermark
                }`}
                style={{
                  backgroundImage: `url('https://images3.alphacoders.com/112/thumbbig-1122539.webp')`,
                }}
              ></div>

              {/* Card Content - ensure it's above the background image */}
              <div className="relative z-10 space-y-4">
                <div className="flex items-center gap-3">
                  <MessageCircle className="text-indigo-500" size={36} /> {/* Soul Icon */}
                  <h4 className="text-2xl font-bold text-gray-900">Soul (2020)</h4>
                </div>
                <p className="text-lg italic text-gray-700 font-semibold">
                  *"Life itself is purpose."*
                </p>
                <p className="text-sm text-gray-500 font-medium">Watch the scene:</p>
                <a
                  href="https://sflix2.to/watch-movie/free-soul-hd-66539.5506261"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex px-6 py-2 rounded-full font-semibold text-white bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600 shadow-md transition-all"
                  onMouseEnter={() => setIsSoulHovered(true)} // Trigger hover state
                  onMouseLeave={() => setIsSoulHovered(false)} // Reset hover state
                >
                  Watch Now →
                </a>
              </div>
            </div>
          </div>

          {/* Reflection Section (Plain Background) */}
          <form onSubmit={handleSubmit} className="p-8 space-y-8">
            <h3 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
              <Edit className="text-purple-500" size={36} />
              Reflection
            </h3>
            <div className="space-y-4">
              <h4 className="text-2xl font-semibold text-gray-800">
                What are you chasing that might already be part of your life?
              </h4>
              <h4 className="text-2xl font-semibold text-gray-800">
                When do you feel most alive — when striving, or when flowing?
              </h4>
            </div>
            <textarea
              className="w-full p-4 rounded-xl bg-gray-50 border border-gray-300 text-gray-900 placeholder-gray-500 focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-200"
              rows={6}
              placeholder="Reflect on the difference between striving and flowing..."
              value={reflectionText}
              onChange={(e) => setReflectionText(e.target.value)}
            ></textarea>

            {submissionStatus === 'success' && (
              <p className="text-success text-center">✅ Submitted successfully!</p>
            )}
            {submissionStatus === 'error' && (
              <p className="text-error text-center">❌ Submission failed. Please try again.</p>
            )}

            <div className="flex justify-between mt-10">
              <button
                type="button"
                onClick={onPrev}
                className="px-6 py-2 rounded-full font-semibold text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 shadow-sm transition-colors"
              >
                Previous
              </button>
              <button
                type="submit"
                className="flex items-center justify-center gap-2 px-6 py-2 rounded-full font-semibold text-white bg-gradient-to-r from-purple-600 to-blue-500 hover:from-purple-700 hover:to-blue-600 shadow-md transition-all"
              >
                Submit & Next <span>→</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Page12_Module4_Story;
