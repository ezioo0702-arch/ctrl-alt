import React, { useRef, useEffect, useState, useCallback } from 'react';
import { Pencil, Eraser, Trash2 } from 'lucide-react';

type Tool = 'pencil' | 'eraser';

const DrawingCanvas: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const contextRef = useRef<CanvasRenderingContext2D | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [tool, setTool] = useState<Tool>('pencil');
  const [color] = useState<string>('#000000'); // Default black for pencil
  const [lineWidth, setLineWidth] = useState<number>(2); // Default pencil width

  const prepareCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (canvas) {
      // Set canvas dimensions for high-DPI screens
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * window.devicePixelRatio;
      canvas.height = rect.height * window.devicePixelRatio;

      const context = canvas.getContext('2d');
      if (context) {
        context.scale(window.devicePixelRatio, window.devicePixelRatio);
        context.lineCap = 'round';
        context.lineJoin = 'round';
        context.strokeStyle = color;
        context.lineWidth = lineWidth;
        contextRef.current = context;
      }
    }
  }, [color, lineWidth]);

  useEffect(() => {
    prepareCanvas();

    // Handle window resize to adjust canvas dimensions
    const handleResize = () => {
      prepareCanvas();
      // For simplicity, clear canvas on resize. A more advanced solution would save/restore state.
      contextRef.current?.clearRect(0, 0, canvasRef.current!.width, canvas.current!.height);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [prepareCanvas]);

  const getCoords = (event: React.MouseEvent | React.TouchEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return { offsetX: 0, offsetY: 0 };

    const rect = canvas.getBoundingClientRect();
    let clientX, clientY;

    if (event instanceof MouseEvent) {
      clientX = event.clientX;
      clientY = event.clientY;
    } else { // TouchEvent
      const touchEvent = event as React.TouchEvent;
      // CRITICAL FIX: Ensure touches array exists and has at least one touch
      if (!touchEvent.touches || touchEvent.touches.length === 0) {
        return { offsetX: 0, offsetY: 0 };
      }
      const touch = touchEvent.touches[0];
      clientX = touch.clientX;
      clientY = touch.clientY;
    }

    return {
      offsetX: clientX - rect.left,
      offsetY: clientY - rect.top,
    };
  };

  const startDrawing = useCallback((event: React.MouseEvent | React.TouchEvent) => {
    const { offsetX, offsetY } = getCoords(event);

    if (contextRef.current) {
      contextRef.current.beginPath();
      contextRef.current.moveTo(offsetX, offsetY);
      setIsDrawing(true);
    }
  }, []);

  const draw = useCallback((event: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing) return;
    event.preventDefault(); // Prevent scrolling on touch devices

    const { offsetX, offsetY } = getCoords(event);

    if (contextRef.current) {
      contextRef.current.globalCompositeOperation = tool === 'pencil' ? 'source-over' : 'destination-out';
      contextRef.current.strokeStyle = tool === 'pencil' ? color : 'rgba(0,0,0,1)'; // Eraser uses transparent color
      contextRef.current.lineWidth = tool === 'pencil' ? lineWidth : 10; // Eraser is wider
      contextRef.current.lineTo(offsetX, offsetY);
      contextRef.current.stroke();
    }
  }, [isDrawing, tool, color, lineWidth]);

  const stopDrawing = useCallback(() => {
    if (contextRef.current) {
      contextRef.current.closePath();
      setIsDrawing(false);
    }
  }, []);

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    const context = contextRef.current;
    if (canvas && context) {
      context.clearRect(0, 0, canvas.width, canvas.height);
      prepareCanvas(); // Re-apply initial settings after clearing
    }
  };

  const selectPencil = () => {
    setTool('pencil');
    setLineWidth(2);
  };

  const selectEraser = () => {
    setTool('eraser');
    setLineWidth(10); // Eraser is typically wider
  };

  return (
    <div className="flex flex-col items-center w-full h-full">
      <div className="flex gap-3 mb-4 p-2 bg-gray-100 rounded-lg shadow-sm border border-gray-200">
        <button
          type="button"
          onClick={selectPencil}
          className={`p-2 rounded-md transition-all ${
            tool === 'pencil' ? 'bg-primary text-white shadow-md' : 'bg-white text-gray-700 hover:bg-gray-50'
          }`}
          aria-label="Pencil tool"
        >
          <Pencil size={20} />
        </button>
        <button
          type="button"
          onClick={selectEraser}
          className={`p-2 rounded-md transition-all ${
            tool === 'eraser' ? 'bg-primary text-white shadow-md' : 'bg-white text-gray-700 hover:bg-gray-50'
          }`}
          aria-label="Eraser tool"
        >
          <Eraser size={20} />
        </button>
        <button
          type="button"
          onClick={clearCanvas}
          className="p-2 rounded-md bg-white text-red-500 hover:bg-red-50 hover:text-red-600 transition-all shadow-sm"
          aria-label="Clear canvas"
        >
          <Trash2 size={20} />
        </button>
      </div>
      <canvas
        ref={canvasRef}
        onMouseDown={startDrawing}
        onMouseMove={draw}
        onMouseUp={stopDrawing}
        onMouseLeave={stopDrawing}
        onTouchStart={startDrawing}
        onTouchMove={draw}
        onTouchEnd={stopDrawing}
        className="flex-1 w-full h-full bg-white rounded-lg border border-gray-300 cursor-crosshair"
        style={{ touchAction: 'none' }} // Prevent scrolling on touch devices
      />
      <p className="text-xs text-gray-500 italic mt-2">Use this space to sketch, doodle, or simply imagine your mandala</p>
    </div>
  );
};

export default DrawingCanvas;
