import React, { useState, useEffect } from 'react';
import Iridescence from './Iridescence';
import {
    Sparkles,
    Lightbulb,
    BookOpen,
    CheckCircle,
    Pen, // For the editor
    Download // For the download button
} from 'lucide-react';

// Declare global window object for jsPDF to satisfy TypeScript
declare global {
  interface Window {
    jspdf: {
      jsPDF: any; // Using 'any' for simplicity, could be more specific with jsPDF types
    };
  }
}

interface PageProps {
  onNext: () => void;
  onPrev: () => void;
}

const Page15_Manifesto: React.FC<PageProps> = ({ onNext, onPrev }) => {
  // State for the editor fields (from provided App.tsx)
  const [userName, setUserName] = useState('');
  const [manifestoText, setManifestoText] = useState('');

  // State for checklist items (from original Page15_Manifesto.tsx, matches provided App.tsx)
  const [checklist, setChecklist] = useState({
    clarityOfGrowth: false,
    linkedLessons: false,
    transformationArc: false,
  });

  // State to track if the jsPDF script has loaded (from provided App.tsx)
  const [isJsPdfLoaded, setIsJsPdfLoaded] = useState(false);

  // Effect to dynamically load the jsPDF script (from provided App.tsx)
  useEffect(() => {
    // Check if script is already on the page (e.g., from a previous load)
    if (window.jspdf) {
        setIsJsPdfLoaded(true);
        return;
    }

    const script = document.createElement('script');
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js';
    script.async = true;
    script.onload = () => {
        // The script loads the 'jspdf' object onto the window
        setIsJsPdfLoaded(true);
    };
    script.onerror = () => {
        console.error("Failed to load jsPDF script.");
    };
    document.body.appendChild(script);

    // Cleanup function to remove script when component unmounts
    return () => {
        // Check if the script was added before trying to remove it
        if (document.body.contains(script)) {
            document.body.removeChild(script);
        }
    };
  }, []); // Empty dependency array means this runs once on mount

  // Checklist handler (from original Page15_Manifesto.tsx, matches provided App.tsx)
  const handleChecklistChange = (item: keyof typeof checklist) => {
    setChecklist((prev) => ({ ...prev, [item]: !prev[item] }));
  };

  // PDF Download Handler (logic from provided App.tsx)
  const handleDownloadPDF = () => {
    // 1. Check if the script is loaded
    if (!isJsPdfLoaded || !window.jspdf) {
        console.error("jsPDF is not loaded yet. Please wait a moment and try again.");
        alert("PDF library is still loading. Please wait a moment and try again.");
        return;
    }

    try {
        // 2. Create a new jsPDF instance from the window object
        const doc = new window.jspdf.jsPDF({
            orientation: 'p',
            unit: 'mm',
            format: 'a4'
        });

        // 3. Get the user's text from state and current date
        const name = userName.trim();
        const text = manifestoText;
        const today = new Date();
        const options: Intl.DateTimeFormatOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        const formattedDate = today.toLocaleDateString('en-US', options);

        // 4. Set document properties
        doc.setProperties({
            title: 'Manifesto of Light',
            subject: 'A personal manifesto',
            author: name || 'User',
            keywords: 'manifesto, light, personal growth, self-discovery',
            creator: 'Manifesto of Light App'
        });

        // --- Build the PDF content ---
        const leftMargin = 20;
        const rightMargin = 20;
        const topMargin = 20; // Start a bit higher for more space
        const bottomMargin = 20;
        const usableWidth = doc.internal.pageSize.getWidth() - leftMargin - rightMargin;
        let yPosition = topMargin;
        const lineHeight = 7; // Standard line height for 12pt font

        // Header: Title
        doc.setFontSize(28); // Larger title
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(40, 40, 40); // Darker text color
        doc.text('Manifesto of Light', leftMargin, yPosition);
        yPosition += 15; // Space after title

        // Subheader: Author and Date
        doc.setFontSize(14);
        doc.setFont('helvetica', 'italic');
        doc.setTextColor(80, 80, 80); // Slightly lighter for metadata

        if (name) {
            doc.text(`By: ${name}`, leftMargin, yPosition);
            yPosition += lineHeight;
        }
        doc.text(`Date: ${formattedDate}`, leftMargin, yPosition);
        yPosition += lineHeight * 2; // More space after metadata

        // Separating Line
        doc.setDrawColor(180, 180, 180); // Medium gray
        doc.setLineWidth(0.5);
        doc.line(leftMargin, yPosition, leftMargin + usableWidth, yPosition);
        yPosition += lineHeight * 2; // Space after line

        // Manifesto Content Heading
        doc.setFontSize(18);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(40, 40, 40);
        doc.text('My Personal Manifesto:', leftMargin, yPosition);
        yPosition += lineHeight * 1.5; // Space after heading

        // Manifesto Text
        doc.setFontSize(12);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(60, 60, 60); // Standard text color
        const textLines = doc.splitTextToSize(text, usableWidth);

        // Function to add text with page breaks
        const addTextWithPageBreaks = (lines: string[], startY: number) => {
            let currentY = startY;
            lines.forEach(line => {
                if (currentY + lineHeight > doc.internal.pageSize.getHeight() - bottomMargin) { // Check for page overflow
                    doc.addPage();
                    currentY = topMargin; // Reset Y for new page
                    doc.setFontSize(10); // Smaller font for continuation header
                    doc.setFont('helvetica', 'italic');
                    doc.setTextColor(120, 120, 120);
                    doc.text(`Manifesto of Light (cont.) - ${name || 'User'}`, leftMargin, currentY);
                    currentY += lineHeight * 2;
                    doc.setFontSize(12); // Revert to normal font size for content
                    doc.setFont('helvetica', 'normal');
                    doc.setTextColor(60, 60, 60);
                }
                doc.text(line, leftMargin, currentY);
                currentY += lineHeight;
            });
            return currentY;
        };

        yPosition = addTextWithPageBreaks(textLines, yPosition);

        // 5. Save the PDF
        doc.save('Manifesto-of-Light.pdf');

    } catch (error) {
        console.error("Error generating PDF:", error);
        alert("Failed to generate PDF. Please try again. If the issue persists, check the console for errors.");
    }
  };

  return (
    <div className="relative min-h-screen w-full overflow-hidden">
      {/* Green aurora background */}
      <Iridescence color={[0.7, 0.85, 0.7]} speed={0.7} amplitude={0.06} mouseReact={true} />
      <div className="relative z-10 min-h-screen w-full flex flex-col justify-center items-center text-center p-4 py-12">

        {/* Main White Card Container */}
        <div className="bg-white w-full max-w-3xl mx-auto rounded-3xl shadow-2xl p-8 md:p-12 flex flex-col gap-8 border border-gray-200 my-12">

          {/* Header and Title */}
          <div className="text-center mb-4">
            <h2 className="text-2xl sm:text-4xl font-bold text-gray-900 tracking-tight mb-2 flex items-center justify-center gap-3">
              <Sparkles className="text-purple-500" size={36} />
              FINAL SYNTHESIS
            </h2>
            <h1 className="text-3xl sm:text-5xl font-extrabold text-gray-900 leading-tight">
              Manifesto of Light
            </h1>
          </div>

          {/* Intro Paragraph */}
          <p className="text-base sm:text-lg text-gray-800 leading-relaxed">
            This is your moment to integrate everything you’ve discovered. Write a living statement that captures your insights, your truth, and your commitment to transformation.
          </p>

          {/* Section 1: Prompts (Light Green Background) */}
          <div className="p-6 sm:p-8 space-y-6 bg-green-100 rounded-xl border border-green-200 text-left">
            <h3 className="text-2xl sm:text-3xl font-bold text-gray-900 flex items-center gap-3 mb-4">
              <Lightbulb className="text-green-500" size={36} />
              Prompts to Guide Your Manifesto
            </h3>
            <ul className="list-none text-base sm:text-lg text-gray-700 space-y-3">
              <li className="flex items-start gap-2">
                <span className="font-medium text-xl">❤️</span>
                <div><span className="font-medium">Strengths as Light:</span> What gifts do you bring to the world? What comes naturally to you that illuminates others?</div>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-medium text-xl">🩹</span>
                <div><span className="font-medium">Wounds as Wisdom:</span> What pain has taught you the most? How have your struggles become your teachers?</div>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-medium text-xl">🌊</span>
                <div><span className="font-medium">Opportunities for Flow:</span> When do you feel most alive? Where does effort meet ease in your life?</div>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-medium text-xl">⭐</span>
                <div><span className="font-medium">Truth I Choose to Live:</span> What core truth will guide your path forward? What do you commit to embodying?</div>
              </li>
            </ul>
          </div>

          {/* Section 2: Sample Manifesto (White Background within the main card) */}
          <div className="p-6 sm:p-8 space-y-6 text-left">
            <h3 className="text-2xl sm:text-3xl font-bold text-gray-900 flex items-center gap-3 mb-4">
              <BookOpen className="text-purple-500" size={36} />
              Sample Manifesto
            </h3>
            <blockquote className="border-l-4 border-purple-500 pl-4 italic text-gray-700 text-lg sm:text-xl py-2 font-semibold space-y-2">
              <p>"I am the ocean, not separate from it."</p>
              <p>"I carry its strength and calm."</p>
              <p>"My path holds my lessons."</p>
              <p>"My light is in being — not becoming."</p>
            </blockquote>
          </div>

          {/* Section 3: Editor Box (NEW - from provided App.tsx) */}
          <div className="p-6 sm:p-8 space-y-6 bg-blue-50 rounded-xl border border-blue-200 text-left">
            <h3 className="text-2xl sm:text-3xl font-bold text-gray-900 flex items-center gap-3 mb-4">
              <Pen className="text-blue-500" size={36} />
              Your Manifesto of Light
            </h3>
            <p className="text-base sm:text-lg text-gray-700">
              Write from your heart. Let your truth flow onto the page.
            </p>

            {/* Name Input */}
            <div className="space-y-2">
              <label htmlFor="userName" className="block text-base font-medium text-gray-700">Your Name (optional)</label>
              <input
                type="text"
                id="userName"
                placeholder="Enter your name..."
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-base p-3 text-gray-900"
              />
            </div>

            {/* Manifesto Text Area */}
            <div className="space-y-2">
              <label htmlFor="manifestoText" className="block text-base font-medium text-gray-700">Your Manifesto</label>
              <textarea
                id="manifestoText"
                rows={12}
                value={manifestoText}
                onChange={(e) => setManifestoText(e.target.value)}
                className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-base p-3 text-gray-900"
                placeholder="I am...&#10;&#10;My strengths...&#10;&#10;My wounds have taught me...&#10;&#10;I feel most alive when...&#10;&#10;The truth I choose to live..."
              />
            </div>
          </div>

          {/* Section 4: Download Button (Updated with loading state) */}
          <button
            onClick={handleDownloadPDF}
            disabled={!isJsPdfLoaded}
            className="w-full flex items-center justify-center py-3 px-6 border border-transparent rounded-lg shadow-lg text-base sm:text-lg font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition-all transform hover:scale-105
                       disabled:bg-gray-400 disabled:cursor-not-allowed"
          >
            <Download className="h-6 w-6 mr-2" />
            {isJsPdfLoaded ? 'Download My Manifesto' : 'Loading PDF...'}
          </button>

          {/* Section 5: Evaluation Checklist (Light Yellow/Cream Background) */}
          <div className="p-6 sm:p-8 space-y-6 bg-yellow-100 rounded-xl border border-yellow-200 text-left">
            <h3 className="text-2xl sm:text-3xl font-bold text-gray-900 flex items-center gap-3 mb-4">
              <CheckCircle className="text-yellow-500" size={36} />
              Evaluation Checklist
            </h3>
            <p className="text-base sm:text-lg text-gray-700 mb-4">
              Reflect on your manifesto creation:
            </p>
            <div className="space-y-3 text-base sm:text-lg">
              <label className="flex items-center gap-3 text-gray-800 cursor-pointer">
                <input
                  type="checkbox"
                  className="form-checkbox h-5 w-5 text-yellow-500 rounded focus:ring-yellow-500 border-gray-300"
                  checked={checklist.clarityOfGrowth}
                  onChange={() => handleChecklistChange('clarityOfGrowth')}
                />
                <span>My manifesto shows clarity of growth.</span>
              </label>
              <label className="flex items-center gap-3 text-gray-800 cursor-pointer">
                <input
                  type="checkbox"
                  className="form-checkbox h-5 w-5 text-yellow-500 rounded focus:ring-yellow-500 border-gray-300"
                  checked={checklist.linkedLessons}
                  onChange={() => handleChecklistChange('linkedLessons')}
                />
                <span>I've linked lessons to module teaching or counselling.</span>
              </label>
              <label className="flex items-center gap-3 text-gray-800 cursor-pointer">
                <input
                  type="checkbox"
                  className="form-checkbox h-5 w-5 text-yellow-500 rounded focus:ring-yellow-500 border-gray-300"
                  checked={checklist.transformationArc}
                  onChange={() => handleChecklistChange('transformationArc')}
                />
                <span>I can see my transformation arc.</span>
              </label>
            </div>
          </div>

          {/* Navigation Buttons */}
          <div className="flex justify-between mt-10">
            <button
              type="button"
              onClick={onPrev}
              className="px-6 py-2 rounded-full font-semibold text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 shadow-sm transition-colors"
            >
              Previous
            </button>
            <button
              type="button"
              onClick={onNext}
              className="flex items-center justify-center gap-2 px-6 py-2 rounded-full font-semibold text-white bg-gradient-to-r from-purple-600 to-blue-500 hover:from-purple-700 hover:to-blue-600 shadow-md transition-all"
            >
              Next <span>→</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Page15_Manifesto;
