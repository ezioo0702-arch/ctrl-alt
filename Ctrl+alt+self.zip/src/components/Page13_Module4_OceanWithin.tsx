import React, { useState } from 'react';
import Iridescence from './Iridescence';
import { Lightbulb, MessageSquare, PenLine, CheckCheck, Shell, ThumbsUp } from 'lucide-react'; // Simplified imports
import saveFormData from '../utils/saveFormData';

interface PageProps {
  onNext: () => void;
  onPrev: () => void;
}

const Page13_Module4_OceanWithin: React.FC<PageProps> = ({ onNext, onPrev }) => {
  const [selectedWords, setSelectedWords] = useState<string[]>([]);
  const [oceanText, setOceanText] = useState('');
  const [flowSentence, setFlowSentence] = useState('');
  const [haikuLines, setHaikuLines] = useState({ line1: '', line2: '', line3: '' });
  const [checklist, setChecklist] = useState({
    reflectedPurpose: false,
    connectedJoyFlow: false,
    expressedPresence: false,
  });
  const [purposeConnectionRating, setPurposeConnectionRating] = useState(0);
  const [submissionStatus, setSubmissionStatus] = useState<'success' | 'error' | null>(null);

  const allWords = [
    'Joy', 'Peace', 'Creative', 'Silence', 'Trust', 'Freedom',
    'Presence', 'Wonder', 'Knowing', 'Gratitude'
  ];

  const handleWordClick = (word: string) => {
    setSelectedWords((prev) =>
      prev.includes(word) ? prev.filter((w) => w !== word) : [...prev, word]
    );
  };

  const handleOceanTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setOceanText(e.target.value);
  };

  const handleFlowSentenceChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setFlowSentence(e.target.value);
  };

  const handleHaikuLineChange = (line: keyof typeof haikuLines, value: string) => {
    setHaikuLines((prev) => ({ ...prev, [line]: value }));
  };

  const handleChecklistChange = (item: keyof typeof checklist) => {
    setChecklist((prev) => ({ ...prev, [item]: !prev[item] }));
  };

  const handlePurposeConnectionRating = (rating: number) => {
    setPurposeConnectionRating(rating);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmissionStatus(null);

    const dataToSave = {
      selectedWords,
      oceanText,
      flowSentence,
      haiku: haikuLines,
      checklist,
      purposeConnectionRating,
    };

    // Call the saveFormData utility
    const success = await saveFormData('module4OceanWithin', dataToSave);

    if (success) {
      setSubmissionStatus('success');
      // Reset form fields after successful submission
      setSelectedWords([]);
      setOceanText('');
      setFlowSentence('');
      setHaikuLines({ line1: '', line2: '', line3: '' });
      setChecklist({ reflectedPurpose: false, connectedJoyFlow: false, expressedPresence: false });
      setPurposeConnectionRating(0);
      // Proceed to the next page after a short delay to show success message
      setTimeout(() => {
        onNext();
      }, 1500);
    } else {
      setSubmissionStatus('error');
    }
  };

  return (
    <div className="relative min-h-screen w-full overflow-hidden">
      {/* Main page background */}
      <Iridescence color={[0.7, 0.85, 0.7]} speed={0.7} amplitude={0.06} mouseReact={true} />
      <div className="relative z-10 min-h-screen w-full flex flex-col justify-center items-center text-center p-4 py-12">
        
        {/* Main White Card Container */}
        <div className="bg-white w-full max-w-4xl rounded-3xl shadow-2xl p-8 md:p-12 flex flex-col gap-8">

          {/* Header and Title */}
          <div className="text-center mb-4">
            <h2 className="text-4xl font-bold text-gray-900 tracking-tight mb-2 flex items-center justify-center gap-3">
              <Lightbulb className="text-purple-500" size={36} />
              MODULE FOUR (CONTINUED)
            </h2>
            <h1 className="text-5xl font-extrabold text-gray-900 leading-tight">
              The Ocean Within
            </h1>
          </div>

          {/* Section 1: Practice Activity (Light Blue Background) */}
          <div className="p-8 space-y-6 bg-blue-100 rounded-xl border border-blue-200">
            <h3 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
              <MessageSquare className="text-blue-500" size={36} /> {/* Ocean icon */}
              Practice Activity: The Ocean Within
            </h3>

            {/* Sub-section 1: Word Selection */}
            <div className="space-y-4 text-left">
              <h4 className="text-2xl font-semibold text-gray-900">Select words that describe your being</h4>
              <p className="text-lg text-gray-700 leading-relaxed">
                Click on the words below that resonate with you. They will flow into your ocean of self.
              </p>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                {allWords.map((word) => (
                  <button
                    key={word}
                    type="button"
                    onClick={() => handleWordClick(word)}
                    className={`px-4 py-2 rounded-full font-medium text-sm transition-all duration-200
                      ${selectedWords.includes(word)
                        ? 'bg-blue-500 text-white shadow-md'
                        : 'bg-blue-100 text-blue-700 border border-blue-300 hover:bg-blue-200'
                      }`}
                  >
                    {word}
                  </button>
                ))}
              </div>
            </div>

            {/* Sub-section 2: Your Ocean */}
            <div className="space-y-4 text-left">
              <h4 className="text-2xl font-semibold text-gray-900">Your Ocean of Self:</h4>
              <p className="text-sm text-gray-600 italic mb-2">Click words above to add them to your ocean.</p>
              <textarea
                className="w-full p-4 rounded-xl bg-white border border-blue-300 text-gray-900 placeholder-gray-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 min-h-[150px]"
                placeholder="Your selected words will appear here..."
                value={selectedWords.join(', ')}
                readOnly
              ></textarea>
            </div>

            {/* Sub-section 3: Sentence Completion */}
            <div className="space-y-4 text-left">
              <h4 className="text-2xl font-semibold text-gray-900">Complete this sentence:</h4>
              <blockquote className="border-l-2 border-blue-400 pl-4 italic text-gray-700 text-lg py-2">
                *"When I am in flow, I am..."*
              </blockquote>
              <textarea
                className="w-full p-4 rounded-xl bg-white border border-blue-300 text-gray-900 placeholder-gray-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 min-h-[120px]"
                placeholder="Use the words you selected or your own words to complete this reflection..."
                value={flowSentence}
                onChange={handleFlowSentenceChange}
              ></textarea>
            </div>
          </div>

          {/* Section 2: Creative Reflection (Light Blue Background) */}
          <div className="p-8 space-y-6 bg-blue-100 rounded-xl border border-blue-200">
            <h3 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
              <PenLine className="text-blue-500" size={36} /> {/* Pen icon */}
              Creative Reflection: Write Your Own Haiku of Presence
            </h3>
            <p className="text-lg text-gray-700 leading-relaxed">
              A haiku captures a moment of awareness in three lines (5-7-5 syllables). Here's an example:
            </p>
            <blockquote className="border-l-2 border-blue-400 pl-4 italic text-gray-700 text-lg py-2">
              <em>"Steam curls from the cup,<br />
              I have time without rushing —<br />
              I am here, enough."</em>
            </blockquote>

            <div className="space-y-4 text-left">
              <h4 className="text-2xl font-semibold text-gray-900 flex items-center gap-2">
                <ThumbsUp className="text-blue-500" size={28} />
                Your Haiku:
              </h4>
              <div className="space-y-3">
                <textarea
                  className="w-full p-4 rounded-xl bg-white border border-blue-300 text-gray-900 placeholder-gray-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 min-h-[80px]"
                  placeholder="Line 1 (5 syllables)"
                  value={haikuLines.line1}
                  onChange={(e) => handleHaikuLineChange('line1', e.target.value)}
                ></textarea>
                <textarea
                  className="w-full p-4 rounded-xl bg-white border border-blue-300 text-gray-900 placeholder-gray-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 min-h-[80px]"
                  placeholder="Line 2 (7 syllables)"
                  value={haikuLines.line2}
                  onChange={(e) => handleHaikuLineChange('line2', e.target.value)}
                ></textarea>
                <textarea
                  className="w-full p-4 rounded-xl bg-white border border-blue-300 text-gray-900 placeholder-gray-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 min-h-[80px]"
                  placeholder="Line 3 (5 syllables)"
                  value={haikuLines.line3}
                  onChange={(e) => handleHaikuLineChange('line3', e.target.value)}
                ></textarea>
              </div>
            </div>
          </div>

          {/* Section 3: Evaluation Checklist (Light Blue Background) */}
          <div className="p-8 space-y-6 bg-blue-100 rounded-xl border border-blue-200">
            <h3 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
              <CheckCheck className="text-blue-500" size={36} />
              Evaluation Checklist
            </h3>
            <p className="text-lg text-gray-700 leading-relaxed">
              Reflect on your experience with this module:
            </p>
            <div className="space-y-3">
              <label className="flex items-center gap-3 text-gray-800 cursor-pointer">
                <input
                  type="checkbox"
                  className="form-checkbox h-5 w-5 text-blue-500 rounded focus:ring-blue-500 border-gray-300"
                  checked={checklist.reflectedPurpose}
                  onChange={() => handleChecklistChange('reflectedPurpose')}
                />
                <span>I reflected on purpose through story and film.</span>
              </label>
              <label className="flex items-center gap-3 text-gray-800 cursor-pointer">
                <input
                  type="checkbox"
                  className="form-checkbox h-5 w-5 text-blue-500 rounded focus:ring-blue-500 border-gray-300"
                  checked={checklist.connectedJoyFlow}
                  onChange={() => handleChecklistChange('connectedJoyFlow')}
                />
                <span>I connected joy to flow.</span>
              </label>
              <label className="flex items-center gap-3 text-gray-800 cursor-pointer">
                <input
                  type="checkbox"
                  className="form-checkbox h-5 w-5 text-blue-500 rounded focus:ring-blue-500 border-gray-300"
                  checked={checklist.expressedPresence}
                  onChange={() => handleChecklistChange('expressedPresence')}
                />
                <span>I expressed presence through creative writing.</span>
              </label>
            </div>
          </div>

          {/* Section 4: Purpose Connection Scale (Light Blue Background) */}
          <div className="p-8 space-y-6 bg-blue-100 rounded-xl border border-blue-200">
            <h3 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
              <Shell className="text-blue-500" size={36} /> {/* Shell icon */}
              Purpose Connection Scale
            </h3>
            <blockquote className="border-l-2 border-blue-400 pl-4 italic text-gray-700 text-lg py-2">
              *"How connected do I feel with my inner purpose?"*
            </blockquote>
            <div className="flex justify-center gap-3">
              {[1, 2, 3, 4, 5].map((rating) => (
                <Shell
                  key={rating}
                  className={`cursor-pointer transition-colors duration-200 ${
                    rating <= purposeConnectionRating ? 'text-blue-400 fill-current' : 'text-gray-400'
                  }`}
                  size={40}
                  onClick={() => handlePurposeConnectionRating(rating)}
                />
              ))}
            </div>
            <p className="text-sm text-gray-700">
              {purposeConnectionRating > 0 ? `You rated: ${purposeConnectionRating} out of 5` : 'Click a shell to rate'}
            </p>
          </div>

          {submissionStatus === 'success' && (
            <p className="text-success text-center text-lg font-semibold">✅ Submitted successfully!</p>
          )}
          {submissionStatus === 'error' && (
            <p className="text-error text-center text-lg font-semibold">❌ Submission failed. Please try again.</p>
          )}

          <div className="flex justify-between mt-10">
            <button
              type="button"
              onClick={onPrev}
              className="px-6 py-2 rounded-full font-semibold text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 shadow-sm transition-colors"
            >
              Previous
            </button>
            {/* The submit button now correctly calls the handleSubmit function */}
            <button
              type="button" // Changed to button to prevent default form submission behavior
              onClick={handleSubmit}
              className="flex items-center justify-center gap-2 px-6 py-2 rounded-full font-semibold text-white bg-gradient-to-r from-purple-600 to-blue-500 hover:from-purple-700 hover:to-blue-600 shadow-md transition-all"
            >
              Next <span>→</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Page13_Module4_OceanWithin;
