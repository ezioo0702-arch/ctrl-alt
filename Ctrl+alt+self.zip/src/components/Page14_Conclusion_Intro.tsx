import React from 'react';
import Iridescence from './Iridescence';
import { Sparkles, Award, Sun } from 'lucide-react'; // Added Sun icon

interface PageProps {
  onNext: () => void;
  onPrev: () => void;
}

const Page14_Conclusion_Intro: React.FC<PageProps> = ({ onNext, onPrev }) => {
  // Placeholder for the commitment text, will be managed by state if needed later
  const [commitment, setCommitment] = React.useState('');

  const handleCommitmentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setCommitment(e.target.value);
  };

  // Placeholder for submission logic if needed
  const handleSubmitCommitment = () => {
    console.log("Commitment:", commitment);
    // In a real app, you'd save this commitment
    onNext(); // Proceed to the next page
  };

  return (
    <div className="relative min-h-screen w-full overflow-hidden">
      {/* Green aurora background */}
      <Iridescence color={[0.7, 0.85, 0.7]} speed={0.7} amplitude={0.06} mouseReact={true} />
      <div className="relative z-10 min-h-screen w-full flex flex-col justify-center items-center text-center p-4 py-12">
        
        {/* Main White Card Container */}
        <div className="bg-white w-full max-w-3xl mx-auto rounded-3xl shadow-2xl p-8 md:p-12 flex flex-col gap-8 border border-gray-200">

          {/* Header and Title */}
          <div className="text-center mb-4">
            <h2 className="text-4xl font-bold text-gray-900 tracking-tight mb-2 flex items-center justify-center gap-3">
              <Sparkles className="text-purple-500" size={36} />
              CHAPTER THREE
            </h2>
            <h1 className="text-5xl font-extrabold text-gray-900 leading-tight">
              Your Transformation Journey
            </h1>
          </div>

          {/* Paragraph 1 */}
          <p className="text-lg text-gray-800 leading-relaxed">
            Transformation is not a linear path. It's a spiral journey where we revisit familiar territories with new eyes, deeper understanding, and greater compassion for ourselves and others.
          </p>

          {/* Paragraph 2 */}
          <p className="text-lg text-gray-800 leading-relaxed">
            As educators and learners, we hold a sacred responsibility: to model the very transformation we wish to see in the world. This means:
          </p>

          {/* Bullet List */}
          <ul className="list-disc list-inside text-left text-lg text-gray-800 space-y-2 ml-6">
            <li className="flex items-center gap-2">
              <Award className="text-purple-500 flex-shrink-0" size={20} />
              <span className="font-medium">Embracing vulnerability</span> as a strength, not a weakness
            </li>
            <li className="flex items-center gap-2">
              <Award className="text-purple-500 flex-shrink-0" size={20} />
              <span className="font-medium">Practicing self-compassion</span> while pursuing growth
            </li>
            <li className="flex items-center gap-2">
              <Award className="text-purple-500 flex-shrink-0" size={20} />
              <span className="font-medium">Creating spaces</span> where others feel safe to transform
            </li>
            <li className="flex items-center gap-2">
              <Award className="text-purple-500 flex-shrink-0" size={20} />
              <span className="font-medium">Recognizing</span> that every ending is also a beginning
            </li>
          </ul>

          {/* Blockquote */}
          <blockquote className="border-l-4 border-purple-500 pl-4 italic text-gray-700 text-xl py-2 font-semibold">
            "We cannot teach what we do not embody. Transformation begins within."
          </blockquote>

          {/* Paragraph 3 */}
          <p className="text-lg text-gray-800 leading-relaxed">
            This eBook is just the beginning. The real work happens in the quiet moments of reflection, in the brave choices we make daily, and in the compassion we extend to ourselves as we grow.
          </p>

          {/* Final Quote */}
          <p className="text-center text-2xl font-bold text-gray-900 mt-8">
            *May your journey be filled with wisdom, courage, and endless possibilities.*
          </p>

          {/* Commitment Box */}
          <div className="bg-yellow-100 border-l-4 border-green-500 rounded-xl p-6 mt-10 text-left flex flex-col gap-4">
            <div className="flex items-center gap-3">
              <Sun className="text-yellow-500" size={32} />
              <h3 className="font-bold text-2xl text-gray-900">Your Commitment</h3>
            </div>
            <p className="text-gray-800 text-lg leading-relaxed">
              What is one small step you commit to taking today toward your own transformation?
            </p>
            <textarea
              className="w-full p-4 rounded-xl bg-white border border-gray-300 text-gray-900 placeholder-gray-500 focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200 min-h-[120px]"
              placeholder="Write your commitment here..."
              value={commitment}
              onChange={handleCommitmentChange}
            ></textarea>
          </div>

          {/* Navigation Buttons */}
          <div className="flex justify-between mt-10">
            <button
              onClick={onPrev}
              className="px-6 py-2 rounded-full font-semibold text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 shadow-sm transition-colors"
            >
              Previous
            </button>
            <button
              onClick={handleSubmitCommitment} // Use the new handler
              className="flex items-center justify-center gap-2 px-6 py-2 rounded-full font-semibold text-white bg-gradient-to-r from-purple-600 to-blue-500 hover:from-purple-700 hover:to-blue-600 shadow-md transition-all"
            >
              Next <span>→</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Page14_Conclusion_Intro;
