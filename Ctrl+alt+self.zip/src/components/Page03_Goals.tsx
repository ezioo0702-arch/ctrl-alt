import React from 'react';
import Iridescence from './Iridescence';

interface PageProps {
  onNext: () => void;
  onPrev: () => void;
}

const Page03_Goals: React.FC<PageProps> = ({ onNext, onPrev }) => {
  return (
    <div className="relative min-h-screen w-full overflow-hidden">
      <Iridescence color={[0.5, 0.7, 0.9]} speed={0.9} amplitude={0.06} mouseReact={true} />
      <div className="relative z-10 min-h-screen w-full flex flex-col justify-center items-center text-center p-4 py-12">
        <div className="max-w-3xl mx-auto bg-white rounded-3xl shadow-2xl p-8 md:p-12 space-y-8 border border-border">
          <p className="text-sm font-medium text-gray-900">COURSE OVERVIEW</p>
          <h2 className="text-4xl font-bold text-gray-900 tracking-tight mb-4">
            What You'll Gain from CTRL + ALT + SELF
          </h2>
          <p className="text-lg text-gray-900 leading-relaxed">
            This transformative journey will guide you through profound insights and practical wisdom, helping you integrate philosophy, psychology, and purpose into your daily life.
          </p>

          <div className="grid grid-cols-1 gap-6 mt-8">
            {/* Section 1: Deepened Self-Awareness */}
            <div className="bg-green-50 border border-green-200 rounded-xl p-6 text-left flex flex-col items-start">
              <span className="text-3xl mb-3" role="img" aria-label="herb">🌿</span>
              <h3 className="font-semibold text-xl text-gray-900 mb-2">Deepened Self-Awareness</h3>
              <p className="text-gray-900 text-sm">
                Explore the intersection of Eastern and Western philosophy to understand yourself more deeply. Through stories, reflections, and practices, you'll develop a richer awareness of your thoughts, emotions, and patterns.
              </p>
            </div>

            {/* Section 2: Emotional Resilience & Reflection */}
            <div className="bg-pink-50 border border-pink-200 rounded-xl p-6 text-left flex flex-col items-start">
              <span className="text-3xl mb-3" role="img" aria-label="cherry blossom">🌸</span>
              <h3 className="font-semibold text-xl text-gray-900 mb-2">Emotional Resilience & Reflection</h3>
              <p className="text-gray-900 text-sm">
                Build the capacity to navigate life's challenges with grace and wisdom. Learn to reflect deeply on your experiences, transforming obstacles into opportunities for growth and understanding.
              </p>
            </div>

            {/* Section 3: Connection Between Purpose & Presence */}
            <div className="bg-green-50 border border-green-200 rounded-xl p-6 text-left flex flex-col items-start">
              <span className="text-3xl mb-3" role="img" aria-label="sheaf of rice">🌾</span>
              <h3 className="font-semibold text-xl text-gray-900 mb-2">Connection Between Purpose & Presence</h3>
              <p className="text-gray-900 text-sm">
                Discover how living in the present moment connects you to your deeper purpose. Learn to find meaning not in distant goals, but in the quality of your attention and presence right now.
              </p>
            </div>

            {/* Section 4: Integration of Joy, Creativity & Mindfulness */}
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-6 text-left flex flex-col items-start">
              <span className="text-3xl mb-3" role="img" aria-label="ocean wave">🌊</span>
              <h3 className="font-semibold text-xl text-gray-900 mb-2">Integration of Joy, Creativity & Mindfulness</h3>
              <p className="text-gray-900 text-sm">
                Experience learning as a joyful, creative practice. Through artistic activities, storytelling, and mindful reflection, you'll rediscover the delight of learning and growing.
              </p>
            </div>

            {/* Section 5: Your Original 'Manifesto of Light' */}
            <div className="bg-purple-50 border border-purple-200 rounded-xl p-6 text-left flex flex-col items-start">
              <span className="text-3xl mb-3" role="img" aria-label="sparkles">✨</span>
              <h3 className="font-semibold text-xl text-gray-900 mb-2">Your Original 'Manifesto of Light'</h3>
              <p className="text-gray-900 text-sm">
                Create a personal expression of your transformation journey. This living document will capture your insights, commitments, and the wisdom you've gathered — a guiding light for your continued growth.
              </p>
            </div>

            {/* Section 6: By the End of This Journey (Large Box) */}
            <div className="bg-green-50 border border-green-200 rounded-xl p-6 text-left flex flex-col items-start">
              <span className="text-3xl mb-3" role="img" aria-label="sparkles">✨</span>
              <h3 className="font-semibold text-xl text-gray-900 mb-2">By the End of This Journey</h3>
              <p className="text-gray-900 text-sm">
                You will have traveled through ancient wisdom and modern insights, created meaningful reflections, and crafted a personal manifesto that embodies your transformation. You'll carry tools for continued growth, a deeper understanding of yourself, and the confidence to guide others on their own journeys.
              </p>
            </div>
          </div>

          <p className="text-center text-gray-900 font-medium mt-8">
            Ready to discover what awaits you? <br /> Let's begin the journey inward 💖
          </p>

          <div className="flex justify-between mt-10">
            <button
              onClick={onPrev}
              className="px-6 py-2 rounded-full font-semibold text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 shadow-sm transition-colors"
            >
              Previous
            </button>
            <button
              onClick={onNext}
              className="flex items-center justify-center gap-2 px-6 py-2 rounded-full font-semibold text-white bg-gradient-to-r from-purple-600 to-blue-500 hover:from-purple-700 hover:to-blue-600 shadow-md transition-all"
            >
              Next <span>→</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Page03_Goals;
