import React, { useState } from 'react';
import Iridescence from './Iridescence';
import { Check } from 'lucide-react'; // Using Check, but you can swap icons

interface FinalPageProps {
  onPrev: () => void;
  goToPage: (pageNumber: number) => void; // Added goToPage for direct navigation
}

/**
 * A React component for the "Reflection" page.
 * This page comes after the progress celebration and before the final certificate page.
 * It collects user's final thoughts and shows a completion message.
 */
const Page16_Completion: React.FC<FinalPageProps> = ({ onPrev, goToPage }) => {
  const [truth, setTruth] = useState("");
  const [selectedEssence, setSelectedEssence] = useState<string | null>(null);

  const essences = [
    { name: 'Peace', icon: '🌊' }, // Using emojis as placeholders
    { name: 'Flow', icon: '🌸' },
    { name: 'Clarity', icon: '🌿' },
    { name: 'Light', icon: '☀️' },
  ];

  // Simple handler for the final "Finish" button
  const handleFinish = () => {
    // Here you could save the `truth` and `selectedEssence` to a database
    console.log("User's truth:", truth);
    console.log("Selected essence:", selectedEssence);
    
    // Navigate to page 1 (the welcome page)
    if (goToPage) {
      goToPage(1);
    }
  };

  return (
    <div className="relative min-h-screen w-full overflow-hidden">
      <Iridescence color={[0.5, 0.9, 0.9]} speed={1.2} amplitude={0.04} mouseReact={true} />
      <div className="relative z-10 min-h-screen w-full flex flex-col justify-center items-center text-center p-4 py-12">
        {/* This div now contains the content from the provided Page15b_Reflection */}
        <div className="w-full max-w-2xl mx-auto space-y-8">

          {/* --- Card 1: Reflection --- */}
          <div 
            className="bg-white rounded-2xl shadow-lg p-8 md:p-10 text-gray-700 border-2 border-green-100" // Adjusted border
          >
            {/* Quote */}
            <div className="text-center mb-8">
              <span className="text-3xl">🕯️</span>
              <h3 
                className="text-2xl italic text-gray-600 mt-2" 
                style={{ fontFamily: "'Playfair Display', serif" }}
              >
                "You were never lost.
              </h3>
              <p 
                className="text-2xl italic text-gray-600" 
                style={{ fontFamily: "'Playfair Display', serif" }}
              >
                You were always the ocean."
              </p>
            </div>

            {/* Text Area */}
            <div className="mb-8">
              <label 
                htmlFor="truth" 
                className="block text-sm font-semibold text-gray-800 mb-2"
              >
                The truth I'll carry forward is...
              </label>
              <textarea
                id="truth"
                rows={4}
                value={truth}
                onChange={(e) => setTruth(e.target.value)}
                placeholder="Write the wisdom you'll take with you into the world..."
                className="w-full p-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition text-gray-900"
              ></textarea>
            </div>

            {/* Essence Choice */}
            <div>
              <label className="block text-sm font-semibold text-gray-800 mb-4 text-center">
                Choose the essence of your journey:
              </label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {essences.map((essence) => (
                  <button
                    key={essence.name}
                    onClick={() => setSelectedEssence(essence.name)}
                    className={`relative flex flex-col items-center justify-center p-4 h-24 border-2 rounded-lg transition-all ${
                      selectedEssence === essence.name
                        ? 'bg-green-100 border-green-600 shadow-md scale-105'
                        : 'bg-white border-gray-300 hover:border-gray-400'
                    }`}
                  >
                    <span className="text-3xl">{essence.icon}</span>
                    <span className="mt-2 text-sm font-medium text-gray-800">{essence.name}</span>
                    {selectedEssence === essence.name && (
                      <div className="absolute top-1 right-1 bg-green-600 rounded-full p-0.5">
                        <Check size={14} className="text-white" />
                      </div>
                    )}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* --- Card 2: Completion Message --- */}
          <div 
            className="bg-white rounded-2xl shadow-lg p-8 md:p-10 text-center border-2 border-green-100" // Adjusted border
          >
            <h2 
              className="text-2xl font-semibold text-green-800 mb-4" 
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              <span className="text-2xl mr-2">☀️</span>
              You Have Completed Your Journey
            </h2>
            <p className="text-lg text-gray-600 leading-relaxed">
              You've paused, reflected, and returned to yourself.
            </p>
            <p className="text-lg text-gray-600 leading-relaxed">
              You've embraced change, found balance, and discovered your flow.
            </p>
            <p className="text-lg text-gray-600 leading-relaxed mb-6">
              You've written your truth.
            </p>
            
            <h3 
              className="text-3xl font-bold text-gray-800" 
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              Now, live it. <span className="text-2xl">🌸</span>
            </h3>
            
            <hr className="my-8 border-gray-300" />
            
            <div className="text-gray-500 text-sm">
              <p className="font-semibold tracking-wide">CTRL + ALT + SELF</p>
              <p className="mt-1">Philosophical Underpinning for Self-Transformation</p>
              <p className="mt-1">UNESCO OE4BW Initiative 2025</p>
            </div>
          </div>

          {/* --- Navigation --- */}
          <div className="flex justify-between w-full">
            <button
              onClick={onPrev}
              className="px-6 py-2 rounded-full font-semibold text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 shadow-sm transition-colors"
            >
              Previous
            </button>
            <button
              onClick={handleFinish}
              disabled={!truth || !selectedEssence}
              className="flex items-center justify-center gap-2 px-6 py-3 rounded-full font-semibold text-gray-900 bg-yellow-300 hover:bg-yellow-400 shadow-md transition-all disabled:bg-gray-200 disabled:cursor-not-allowed disabled:shadow-none"
            >
              Finish Journey
              <span>→</span>
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};

export default Page16_Completion;
