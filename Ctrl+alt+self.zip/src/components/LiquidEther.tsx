<boltAction type="file" filePath="src/components/LiquidEther.css" delete="true" />
<boltAction type="shell">
npm install
