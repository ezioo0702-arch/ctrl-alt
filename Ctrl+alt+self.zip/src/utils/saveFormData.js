import { collection, addDoc } from 'firebase/firestore';
import { db, serverTimestamp } from '../firebase';

/**
 * Saves form data to a specified Firestore collection.
 * @param {string} moduleName The name of the Firestore collection.
 * @param {object} data The data object to save.
 * @returns {Promise<boolean>} True if successful, false otherwise.
 */
export async function saveFormData(moduleName, data) {
  try {
    console.log(`Attempting to save to '${moduleName}':`, data);
    const docRef = await addDoc(collection(db, moduleName), {
      ...data,
      createdAt: serverTimestamp(), // Use createdAt as per example
    });
    console.log(`✅ Saved successfully to '${moduleName}' with ID:`, docRef.id);
    return true;
  } catch (err) {
    console.error(`❌ Firestore error for '${moduleName}':`, err.code, err.message, err);
    return false;
  }
}

export default saveFormData;
