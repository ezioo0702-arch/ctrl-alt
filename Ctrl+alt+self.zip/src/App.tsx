import React, { useState } from 'react';

// --- IMPORT OUR FIRST PAGE ---
import Page01_Welcome from './components/Page01_Welcome';
import Page02_HowTo from './components/Page02_HowTo';
import Page03_Goals from './components/Page03_Goals';
import Page04_Intro1 from './components/Page04_Intro1';
import Page05_Intro2 from './components/Page05_Intro2';
import Page06_Module1_Story from './components/Page06_Module1_Story';
import Page07_Module1_Practice from './components/Page07_Module1_Practice';
import Page08_Module2_Story from './components/Page08_Module2_Story';
import Page09_Module2_Practice from './components/Page09_Module2_Practice';
import Page10_Module3_Story from './components/Page10_Module3_Story';
import Page11_Module3_Practice from './components/Page11_Module3_Practice';
import Page12_Module4_Story from './components/Page12_Module4_Story';
import Page13_Module4_OceanWithin from './components/Page13_Module4_OceanWithin'; // Corrected import name
import Page13_Module4_Practice from './components/Page13_Module4_Practice';
import Page14_Conclusion_Intro from './components/Page14_Conclusion_Intro';
import Page15_Manifesto from './components/Page15_Manifesto';
import Page16_Completion from './components/Page16_Completion';
import Navbar from './components/Navbar';
// We will add imports for pages 2-16 here

// --- MAIN APP COMPONENT ---
function App() {
  // We have 16 pages, so we'll cap at 16
  const [page, setPage] = useState(1);

  const nextPage = () => setPage((p) => (p < 16 ? p + 1 : 16));
  const prevPage = () => setPage((p) => (p > 1 ? p - 1 : 1));
  const goToPage = (pageNumber: number) => setPage(pageNumber);

  // --- Prop Interfaces ---
  interface PageProps {
    onNext: () => void;
    onPrev: () => void;
  }
  interface FinalPageProps {
    onPrev: () => void;
    goToPage: (page: number) => void;
  }
  interface WelcomePageProps {
    onNext: () => void;
  }

  // This function will decide which page to show
  const renderPage = () => {
    switch (page) {
      case 1:
        return <Page01_Welcome onNext={nextPage} />;
      case 2:
        return <Page02_HowTo onNext={nextPage} onPrev={prevPage} />;
      case 3:
        return <Page03_Goals onNext={nextPage} onPrev={prevPage} />;
      case 4:
        return <Page04_Intro1 onNext={nextPage} onPrev={prevPage} />;
      case 5:
        return <Page05_Intro2 onNext={nextPage} onPrev={prevPage} />;
      case 6:
        return <Page06_Module1_Story onNext={nextPage} onPrev={prevPage} />;
      case 7:
        return <Page07_Module1_Practice onNext={nextPage} onPrev={prevPage} />;
      case 8:
        return <Page08_Module2_Story onNext={nextPage} onPrev={prevPage} />;
      case 9:
        return <Page09_Module2_Practice onNext={nextPage} onPrev={prevPage} />;
      case 10:
        return <Page10_Module3_Story onNext={nextPage} onPrev={prevPage} />;
      case 11:
        return <Page11_Module3_Practice onNext={nextPage} onPrev={prevPage} />;
      case 12:
        return <Page12_Module4_Story onNext={nextPage} onPrev={prevPage} />;
      case 13:
        // Explicitly render Page13_Module4_OceanWithin for page 13
        return <Page13_Module4_OceanWithin onNext={nextPage} onPrev={prevPage} />;
      case 14:
        return <Page14_Conclusion_Intro onNext={nextPage} onPrev={prevPage} />;
      case 15:
        return <Page15_Manifesto onNext={nextPage} onPrev={prevPage} />;
      case 16:
        return <Page16_Completion goToPage={goToPage} onPrev={prevPage} />;

      // We will add 'case 3:', etc. here

      default:
        return <Page01_Welcome onNext={nextPage} />;
    }
  };

  // The 'return' is simple. It just renders the active page.
  return (
     <>
      {/* Add navbar here */}
      <Navbar goToPage={goToPage} />

      {/* Add top padding so content is not hidden behind navbar */}
      <div>
        {renderPage()}
      </div>
    </>
  );
}

export default App;
